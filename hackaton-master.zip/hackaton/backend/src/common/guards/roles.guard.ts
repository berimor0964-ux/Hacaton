import { Injectable, CanActivate, ExecutionContext, ForbiddenException, UnauthorizedException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { DataSource } from 'typeorm';

// 👇 Создаем декоратор для навешивания ролей
export const Roles = (...roles: string[]) => SetMetadata('roles', roles);
import { SetMetadata } from '@nestjs/common';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(
    private reflector: Reflector,
    private dataSource: DataSource,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    // 1. Достаем роли, которые разрешены для этого эндпоинта
    const requiredRoles = this.reflector.getAllAndOverride<string[]>('roles', [
      context.getHandler(),
      context.getClass(),
    ]);

    // Если роли не указаны — пускаем всех (например, для логина)
    if (!requiredRoles || requiredRoles.length === 0) {
      return true;
    }

    const request = context.switchToHttp().getRequest();
    
    // 2. Достаем ID пользователя из заголовка (фронтенд должен его прислать)
    const userId = request.headers['x-user-id'];

    if (!userId) {
      throw new UnauthorizedException('Нет доступа. Заголовок x-user-id отсутствует.');
    }

    // 3. Ищем пользователя в базе и его роли
    // (Используем сырой SQL-запрос для скорости, чтобы не тянуть сущности)
    const users = await this.dataSource.query(
      `SELECT r.name as role 
       FROM users u
       JOIN user_roles ur ON u.id = ur.userId
       JOIN roles r ON r.id = ur.roleId
       WHERE u.id = $1`,
      [userId]
    );

    if (!users || users.length === 0) {
      throw new ForbiddenException('Пользователь не найден или у него нет ролей.');
    }

    const userRoles = users.map((u: any) => u.role);

    // 4. Проверяем, есть ли у пользователя нужная роль
    const hasRole = requiredRoles.some((role) => userRoles.includes(role));

    if (!hasRole) {
      throw new ForbiddenException('У вас недостаточно прав для этого действия.');
    }

    return true;
  }
}