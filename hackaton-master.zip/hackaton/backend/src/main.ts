import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module.js';
import { NestExpressApplication } from '@nestjs/platform-express';
import { join, dirname } from 'path'; // <-- Добавили dirname
import { ValidationPipe } from '@nestjs/common';
import { fileURLToPath } from 'url';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  // Правильное определение __dirname для ES-модулей
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = dirname(__filename); // <-- ИСПРАВЛЕНО: dirname вместо join

  // Теперь путь к uploads будет корректным
  app.useStaticAssets(join(__dirname, '..', 'uploads'), {
    prefix: '/uploads/',
  });

  app.enableCors({
    origin: 'http://localhost:5173',
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    credentials: true,
    allowedHeaders: 'Content-Type, Accept, Authorization, x-user-id',
  });

  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
  await app.listen(process.env.PORT ?? 3000);
}

bootstrap();