import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { fileURLToPath } from 'url';
 import { dirname, join } from 'path';

 const __filename = fileURLToPath(import.meta.url);
 const __dirname = dirname(__filename);

@Module({
  imports: [
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'postgres',
        host: config.get<string>('DB_HOST', 'localhost'),
        port: config.get<number>('DB_PORT', 5432),
        username: config.get<string>('DB_USER', 'postgres'),
        password: config.get<string>('DB_PASSWORD', 'postgres'),
        database: config.get<string>('DB_NAME', 'hackaton'),
        entities: [__dirname + '/../**/*.entity{.ts,.js}'],
        synchronize: true,   
        logging: true,
        autoLoadEntities: true
      }),
    }),
  ],
})
export class DatabaseModule {}