import { Module } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';
import { APP_GUARD } from '@nestjs/core';

import { DatabaseModule } from './database/database.module.js';

import { UsersModule } from './modules/users/users.module.js';
import { RolesModule } from './modules/roles/roles.module.js';
import { EventsModule } from './modules/events/events.module.js';
import { AssignmentsModule } from './modules/assignments/assignments.module.js';
import { MediaModule } from './modules/media/media.module.js';
import { TranscriptionModule } from './modules/transcription/transcription.module.js';
import { StoriesModule } from './modules/stories/stories.module.js';
import { ProjectsModule } from './modules/projects/projects.module.js';
import { EditorialModule } from './modules/editorial/editorial.module.js';
import { BroadcastsModule } from './modules/broadcasts/broadcasts.module.js';
import { NotificationsModule } from './modules/notifications/notifications.module.js';
import { TasksModule } from './modules/tasks/tasks.module.js';

import { SearchModule } from './integrations/search/search.module.js';
import { StorageModule } from './integrations/storage/storage.module.js';

import { WorkersModule } from './workers/workers.module.js';
import { ConfigModule } from '@nestjs/config';
import { TranscriptionIntegrationModule } from './integrations/transcription/transcription.module.js';
import { AuthModule } from './modules/auth/auth.module.js';
import { RolesGuard } from './common/guards/roles.guard.js';

@Module({
  imports: [
    ScheduleModule.forRoot(),
    ConfigModule.forRoot({ isGlobal: true }),
    DatabaseModule,

    UsersModule,
    RolesModule,
    EventsModule,
    AssignmentsModule,
    MediaModule,
    TranscriptionModule,
    StoriesModule,
    ProjectsModule,
    EditorialModule,
    BroadcastsModule,
    NotificationsModule,
    TasksModule,

    SearchModule,
    StorageModule,
    TranscriptionIntegrationModule,

    WorkersModule,

    AuthModule,
  ],
  providers: [
    {
      provide: APP_GUARD,
      useClass: RolesGuard,
    },
  ],
})
export class AppModule {}