import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { User } from './entities/user.entity.js';
import { UserAvailability } from './entities/user-availability.entity.js';
import { Role } from '../roles/entities/role.entity.js';
import { CreateUserDto } from './dto/create-user.dto.js';
import { CreateAvailabilityDto } from './dto/create-availability.dto.js';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private readonly usersRepository: Repository<User>,
    @InjectRepository(UserAvailability)
    private readonly availabilityRepository: Repository<UserAvailability>,
    @InjectRepository(Role) // 👈 нужен репозиторий ролей для привязки
    private readonly rolesRepository: Repository<Role>,
  ) {}

  async findByEmail(email: string): Promise<User | null> {
    return this.usersRepository.findOne({ where: { email } });
  }

  async findById(id: number): Promise<User | null> {
    return this.usersRepository.findOne({ where: { id },
      relations: { roles: true } });
  }
  async getAll(): Promise<User[]> {
    return this.usersRepository.find({
      relations: { roles: true }
    });
  }
  async create(dto: CreateUserDto): Promise<User> {
    const existing = await this.usersRepository.findOne({ where: { email: dto.email } });
    if (existing) throw new ConflictException('Email уже занят');

    const user = new User();
    user.email = dto.email;
    user.password = dto.password;
    user.name = dto.name;

    if (dto.roleIds && dto.roleIds.length > 0) {
      // Ищем роли по ID
      user.roles = await this.rolesRepository.findBy({ id: In(dto.roleIds) });
    }

    return this.usersRepository.save(user);
  }

  async addAvailability(userId: number, dto: CreateAvailabilityDto) {
    const user = await this.findById(userId);
    if (!user) throw new NotFoundException('Пользователь не найден');

    const availability = this.availabilityRepository.create({
      userId,
      dateStart: new Date(dto.dateStart),
      dateEnd: new Date(dto.dateEnd),
      note: dto.note,
    });

    return this.availabilityRepository.save(availability);
  }
}
