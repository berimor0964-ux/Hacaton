import { IsDateString, IsOptional, IsString } from 'class-validator';

export class CreateAvailabilityDto {
  @IsDateString()
  dateStart: string;

  @IsDateString()
  dateEnd: string;

  @IsOptional()
  @IsString()
  note?: string;
}