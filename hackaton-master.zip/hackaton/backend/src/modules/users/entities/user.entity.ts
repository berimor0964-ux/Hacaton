import { Entity, PrimaryGeneratedColumn, Column, ManyToMany, JoinTable, OneToMany } from 'typeorm';
import { Role } from '../../roles/entities/role.entity.js';
import { UserAvailability } from './user-availability.entity.js';

export enum UserStatus {
  FREE = 'free',
  BUSY = 'busy',
}

@Entity('users')
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  email: string;

  @Column()
  password: string;

  @Column()
  name: string;

  @Column({
    type: 'enum',
    enum: UserStatus,
    default: UserStatus.FREE,
  })
  status: UserStatus;

  // Связь с ролями
  @ManyToMany(() => Role, (role) => role.users, { eager: true })
  @JoinTable({ name: 'user_roles' }) // Таблица связки user_roles
  roles: Role[];

  // Связь с графиком доступности
  @OneToMany(() => UserAvailability, (availability) => availability.user)
  availability: UserAvailability[];
}