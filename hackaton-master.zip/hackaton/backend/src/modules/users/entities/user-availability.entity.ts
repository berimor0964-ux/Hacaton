import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';

@Entity('user_availability')
export class UserAvailability {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  userId: number;

  @Column({ type: 'timestamp' })
  dateStart: Date;

  @Column({ type: 'timestamp' })
  dateEnd: Date;

  @Column({ nullable: true })
  note: string;

  @ManyToOne('User', 'availability', { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'userId' })
  user: any; // 👈 Временный тип any, чтобы не было ошибки TS
}