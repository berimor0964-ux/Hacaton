import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  ParseIntPipe,
  NotFoundException,
} from '@nestjs/common';
import { UsersService } from './users.service.js';
import { CreateUserDto } from './dto/create-user.dto.js';
import { UpdateUserDto } from './dto/update-user.dto.js';
import { CreateAvailabilityDto } from './dto/create-availability.dto.js';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post()
  async create(@Body() createUserDto: CreateUserDto) {
    const user = await this.usersService.create(createUserDto);
    return this.toSafeUser(user);   // 👈 не отдаём password наружу
  }

  @Get()
  async findAll() {
    const users = await this.usersService.getAll();
    return users.map((u) => this.toSafeUser(u));
  }

  @Get(':id')
  async findOne(@Param('id', ParseIntPipe) id: number) {
    const user = await this.usersService.findById(id);
    if (!user) {
      throw new NotFoundException(`Пользователь с id=${id} не найден`);
    }
    return this.toSafeUser(user);
  }

  @Post(':id/availability')
  addAvailability(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: CreateAvailabilityDto,
  ) {
    return this.usersService.addAvailability(id, dto);
  }








  @Patch(':id')
  update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateUserDto: UpdateUserDto,
  ) {
    // TODO: реализовать позже (см. ниже)
    return { message: 'Not implemented yet', id, updateUserDto };
  }

  @Delete(':id')
  remove(@Param('id', ParseIntPipe) id: number) {
    // TODO: реализовать позже (см. ниже)
    return { message: 'Not implemented yet', id };
  }

  // 🔒 Убираем password из ответа
  private toSafeUser(user: { id: number; email: string; name: string; password?: string }) {
    return {
      id: user.id,
      email: user.email,
      name: user.name,
    };
  }
}