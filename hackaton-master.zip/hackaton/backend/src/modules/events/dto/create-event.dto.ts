import { IsString, IsNotEmpty, IsDateString, IsOptional, IsEnum } from 'class-validator';
import { EventStatus } from '../entities/event.entity.js';

export class CreateEventDto {
  @IsString()
  @IsNotEmpty()
  title: string;

  @IsDateString() // Ожидает строку в формате ISO (например, "2023-11-01T10:00:00.000Z")
  dateStart: string;

  @IsDateString()
  dateEnd: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  @IsEnum(EventStatus)
  status?: EventStatus;
}