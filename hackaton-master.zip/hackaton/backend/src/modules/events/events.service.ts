import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateEventDto } from './dto/create-event.dto.js';
import { Event, EventStatus } from './entities/event.entity.js';
import { UpdateEventDto } from './dto/update-event.dto.js';

@Injectable()
export class EventsService {
  constructor(
    @InjectRepository(Event)
    private readonly eventsRepository: Repository<Event>,
  ) {}

  async create(createEventDto: CreateEventDto): Promise<Event> {
    const event = this.eventsRepository.create({
      ...createEventDto,
      dateStart: new Date(createEventDto.dateStart),
      dateEnd: new Date(createEventDto.dateEnd),
    });
    return this.eventsRepository.save(event);
  }

  async findAll(status?: EventStatus): Promise<Event[]> {
    if (status) {
      return this.eventsRepository.find({ where: { status } });
    }
    return this.eventsRepository.find({ order: { dateStart: 'ASC' } });
  }

  async findOne(id: number): Promise<Event> {
    const event = await this.eventsRepository.findOne({ where: { id } });
    if (!event) {
      throw new NotFoundException(`Событие с ID ${id} не найдено`);
    }
    return event;
  }

  async update(id: number, updateEventDto: UpdateEventDto): Promise<Event> {
    // 1. Находим событие в базе
    const event = await this.eventsRepository.findOne({ where: { id } });
    
    if (!event) {
      throw new NotFoundException(`Событие с ID ${id} не найдено`);
    }
  
    // 2. Безопасно обновляем только те поля, которые пришли (используем Object.assign)
    if (updateEventDto.title !== undefined) {
      event.title = updateEventDto.title;
    }
    if (updateEventDto.description !== undefined) {
      event.description = updateEventDto.description;
    }
    if (updateEventDto.dateStart !== undefined) {
      event.dateStart = new Date(updateEventDto.dateStart);
    }
    if (updateEventDto.dateEnd !== undefined) {
      event.dateEnd = new Date(updateEventDto.dateEnd);
    }
    if (updateEventDto.status !== undefined) {
      event.status = updateEventDto.status;
    }
  
    // 3. Сохраняем
    return this.eventsRepository.save(event);
  }

  async remove(id: number) {
    const event = await this.eventsRepository.findOneBy({ id });
    if (!event) throw new NotFoundException('Событие не найдено');
    return this.eventsRepository.remove(event);
  }
}