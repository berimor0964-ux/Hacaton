import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EventsController } from './events.controller.js';
import { Event } from './entities/event.entity.js';
import { EventsService } from './events.service.js';
import { EventsCronService } from './event.cron.js';

@Module({
  imports: [TypeOrmModule.forFeature([Event])],
  controllers: [EventsController],
  providers: [EventsService, EventsCronService], 
  exports: [TypeOrmModule, EventsService],
})
export class EventsModule {}