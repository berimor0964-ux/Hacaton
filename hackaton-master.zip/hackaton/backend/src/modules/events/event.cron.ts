import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, LessThanOrEqual, MoreThanOrEqual } from 'typeorm';
import { Event, EventStatus } from './entities/event.entity.js';

@Injectable()
export class EventsCronService {
  private readonly logger = new Logger(EventsCronService.name);

  constructor(
    @InjectRepository(Event)
    private readonly eventsRepository: Repository<Event>,
  ) {}

  // 👇 Запускается каждую минуту
  @Cron(CronExpression.EVERY_MINUTE)
  async handleEventStatuses() {
    const now = new Date();

    // 1. Ищем события, которые должны стать активными (время пришло, но статус еще planned)
    const toActivate = await this.eventsRepository.find({
      where: {
        status: EventStatus.PLANNED,
        dateStart: LessThanOrEqual(now),
        dateEnd: MoreThanOrEqual(now),
      },
    });

    if (toActivate.length > 0) {
      for (const event of toActivate) {
        event.status = EventStatus.ACTIVE;
        await this.eventsRepository.save(event);
        this.logger.log(`Событие "${event.title}" (ID: ${event.id}) стало АКТИВНЫМ`);
      }
    }

    // 2. Ищем события, которые должны стать завершенными (время вышло)
    // (В будущем здесь мы добавим проверку, что все рендеры сданы)
    const toComplete = await this.eventsRepository.find({
      where: {
        status: EventStatus.ACTIVE,
        dateEnd: LessThanOrEqual(now),
      },
    });

    if (toComplete.length > 0) {
      for (const event of toComplete) {
        event.status = EventStatus.COMPLETED;
        await this.eventsRepository.save(event);
        this.logger.log(`Событие "${event.title}" (ID: ${event.id}) ЗАВЕРШЕНО`);
      }
    }
  }
}