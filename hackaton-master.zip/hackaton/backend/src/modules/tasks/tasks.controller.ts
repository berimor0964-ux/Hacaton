import { Controller, Post, Body, Param, ParseIntPipe, Get, Patch, Delete } from '@nestjs/common';
import { TasksService } from './tasks.service.js';
import { TaskStatus } from './entities/task.entity.js';

@Controller('tasks')
export class TasksController {
  constructor(private readonly tasksService: TasksService) {}

  @Post()
  create(
    @Body() body: { title: string; description?: string; assigneeId: number; authorId: number; deadline?: string },
  ) {
    return this.tasksService.create(body);
  }

  // Получить задачи репортера
  @Get('assignee/:assigneeId')
  findByAssignee(@Param('assigneeId', ParseIntPipe) assigneeId: number) {
    return this.tasksService.findByAssignee(assigneeId);
  }

  // Изменить статус задачи
  @Patch(':id/status')
  updateStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { status: TaskStatus },
  ) {
    return this.tasksService.updateStatus(id, body.status);
  }

  @Delete(':id')
  remove(@Param('id', ParseIntPipe) id: number) {
    return this.tasksService.remove(id);
  }
}