import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Task, TaskStatus } from './entities/task.entity.js';

@Injectable()
export class TasksService {
  constructor(
    @InjectRepository(Task)
    private readonly tasksRepository: Repository<Task>,
  ) {}

  async create(data: { title: string; description?: string; assigneeId: number; authorId: number; deadline?: string }) {
    const task = this.tasksRepository.create({
      title: data.title,
      description: data.description,
      assigneeId: data.assigneeId,
      authorId: data.authorId,
      deadline: data.deadline ? new Date(data.deadline) : undefined, // 👈 Используем undefined вместо null
    });
    
    return this.tasksRepository.save(task);
  }

  // Получить задачи конкретного репортера (его личный кабинет)
  async findByAssignee(assigneeId: number) {
    return this.tasksRepository.find({
      where: { assigneeId },
      order: { createdAt: 'DESC' },
    });
  }

  // Обновить статус задачи (например, взять в работу или выполнить)
  async updateStatus(id: number, status: TaskStatus) {
    const task = await this.tasksRepository.findOne({ where: { id } });
    if (!task) throw new NotFoundException('Задача не найдена');
    
    task.status = status;
    return this.tasksRepository.save(task);
  }

  // Удалить задачу
  async remove(id: number) {
    const result = await this.tasksRepository.delete(id);
    if (result.affected === 0) throw new NotFoundException('Задача не найдена');
    return { message: 'Задача удалена' };
  }
}