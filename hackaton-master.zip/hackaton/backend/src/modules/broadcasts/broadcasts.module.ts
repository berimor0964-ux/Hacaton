import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Broadcast } from './entities/broadcast.entity.js';
import { BroadcastItem } from './entities/broadcast-item.entity.js';
import { Project } from '../projects/entities/project.entity.js';
import { BroadcastsController } from './broadcasts.controller.js';
import { BroadcastsService } from './broadcasts.service.js';

@Module({
  imports: [TypeOrmModule.forFeature([Broadcast, BroadcastItem, Project])],
  controllers: [BroadcastsController],
  providers: [BroadcastsService],
})
export class BroadcastsModule {}