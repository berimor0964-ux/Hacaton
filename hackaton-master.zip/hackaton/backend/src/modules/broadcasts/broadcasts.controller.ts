import { Controller, Post, Body, Param, ParseIntPipe, Get } from '@nestjs/common';
import { BroadcastsService } from './broadcasts.service.js';
import { Roles } from '../../common/guards/roles.guard.js';

@Controller('broadcasts')
export class BroadcastsController {
  constructor(private readonly broadcastsService: BroadcastsService) {}


  @Roles('admin', 'director', 'editor')
  @Post()
  create(@Body() body: { title: string; dateStart: string; dateEnd: string; directorId: number }) {
    return this.broadcastsService.create(body);
  }


  @Roles('admin', 'director', 'editor')
  @Post(':id/items')
  addItem(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { type: string; projectId?: number; startTime: string; endTime: string },
  ) {
    return this.broadcastsService.addItem(id, body);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.broadcastsService.findOne(id);
  }
}