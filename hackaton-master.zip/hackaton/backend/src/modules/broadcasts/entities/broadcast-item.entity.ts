import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';

@Entity('broadcast_items')
export class BroadcastItem {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  broadcastId: number;

  // 'reportage' (готовый проект), 'studio' (студия), 'ad' (реклама), 'film' (фильм)
  @Column()
  type: string;

  // Если это репортаж, здесь ID готового проекта
  @Column({ nullable: true })
  projectId: number;

  // Тайм-коды на сетке вещания
  @Column({ type: 'timestamp' })
  startTime: Date;

  @Column({ type: 'timestamp' })
  endTime: Date;

  @Column({ default: 0 })
  orderIndex: number;

  @ManyToOne('Broadcast', 'items', { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'broadcastId' })
  broadcast: any;
}