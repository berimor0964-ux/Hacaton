import { Entity, PrimaryGeneratedColumn, Column, OneToMany, CreateDateColumn } from 'typeorm';
import { BroadcastItem } from './broadcast-item.entity.js';

export enum BroadcastStatus {
  DRAFT = 'draft',       // Черновик
  READY = 'ready',       // Все элементы готовы
  WARNING = 'warning',   // 🔴 Красный (за 12 часов есть неготовые элементы)
  ON_AIR = 'on_air',     // В эфире
  COMPLETED = 'completed' // Завершен
}

@Entity('broadcasts')
export class Broadcast {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  title: string;

  @Column({ type: 'timestamp' })
  dateStart: Date;

  @Column({ type: 'timestamp' })
  dateEnd: Date;

  @Column()
  directorId: number; // Выпускающий режиссер

  @Column({ type: 'enum', enum: BroadcastStatus, default: BroadcastStatus.DRAFT })
  status: BroadcastStatus;

  @CreateDateColumn()
  createdAt: Date;

  @OneToMany(() => BroadcastItem, (item: BroadcastItem) => item.broadcast, { cascade: true })
  items: BroadcastItem[];
}