import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Cron, CronExpression } from '@nestjs/schedule';
import { Broadcast, BroadcastStatus } from './entities/broadcast.entity.js';
import { BroadcastItem } from './entities/broadcast-item.entity.js';
import { Project, ProjectStatus } from '../projects/entities/project.entity.js';

@Injectable()
export class BroadcastsService {
  private readonly logger = new Logger(BroadcastsService.name);

  constructor(
    @InjectRepository(Broadcast)
    private readonly broadcastsRepository: Repository<Broadcast>,
    @InjectRepository(BroadcastItem)
    private readonly itemsRepository: Repository<BroadcastItem>,
    @InjectRepository(Project)
    private readonly projectsRepository: Repository<Project>,
  ) {}

  async create(data: { title: string; dateStart: string; dateEnd: string; directorId: number }) {
    const broadcast = this.broadcastsRepository.create({
      ...data,
      dateStart: new Date(data.dateStart),
      dateEnd: new Date(data.dateEnd),
    });
    return this.broadcastsRepository.save(broadcast);
  }

  async addItem(broadcastId: number, data: { type: string; projectId?: number; startTime: string; endTime: string }) {
    const broadcast = await this.broadcastsRepository.findOne({ where: { id: broadcastId } });
    if (!broadcast) throw new NotFoundException('Эфир не найден');

    const item = this.itemsRepository.create({
      broadcastId,
      type: data.type,
      projectId: data.projectId,
      startTime: new Date(data.startTime),
      endTime: new Date(data.endTime),
    });
    return this.itemsRepository.save(item);
  }

  async findOne(id: number) {
    return this.broadcastsRepository.findOne({
      where: { id },
      relations: { items: true },
      order: { items: { orderIndex: 'ASC' } },
    });
  }

  // ⏰ CRON: Каждую минуту проверяем, не нужно ли зажечь "красный" эфир
  @Cron(CronExpression.EVERY_MINUTE)
  async checkBroadcastReadiness() {
    const now = new Date();
    const twelveHoursLater = new Date(now.getTime() + 12 * 60 * 60 * 1000);

    // Ищем эфиры, которые начнутся в ближайшие 12 часов и еще не в статусе WARNING
    const upcomingBroadcasts = await this.broadcastsRepository.find({
      where: {
        status: BroadcastStatus.DRAFT,
        // (тут должен быть фильтр по датам, но для простоты проверяем все черновики)
      },
      relations: { items: true },
    });

    for (const broadcast of upcomingBroadcasts) {
      // Если до эфира осталось меньше 12 часов
      if (broadcast.dateStart <= twelveHoursLater && broadcast.dateStart > now) {
        let hasProblems = false;

        // Проверяем каждый элемент сетки
        for (const item of broadcast.items) {
          if (item.type === 'reportage' && item.projectId) {
            const project = await this.projectsRepository.findOne({ where: { id: item.projectId } });
            if (!project || project.status !== ProjectStatus.DONE) {
              hasProblems = true;
              break;
            }
          }
        }

        if (hasProblems) {
          broadcast.status = BroadcastStatus.WARNING;
          await this.broadcastsRepository.save(broadcast);
          this.logger.warn(`🔴 ЭФИР "${broadcast.title}" (ID: ${broadcast.id}) ГОРИТ КРАСНЫМ! Есть неготовые элементы.`);
        }
      }
    }
  }
}