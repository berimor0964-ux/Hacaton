export class CreateBroadcastDto {}
