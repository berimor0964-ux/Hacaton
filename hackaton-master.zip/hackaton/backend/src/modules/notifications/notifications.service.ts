import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Notification, NotificationType } from './entities/notification.entity.js';

@Injectable()
export class NotificationsService {
  constructor(
    @InjectRepository(Notification)
    private readonly notificationsRepository: Repository<Notification>,
  ) {}

  // 👇 Этот метод мы будем вызывать из других модулей!
  async create(
    userId: number,
    type: NotificationType,
    title: string,
    message: string,
    payload?: any,
  ) {
    // 👇 Создаем объект вручную, чтобы TypeScript точно видел все поля
    const notification = this.notificationsRepository.create({
      userId: userId,
      type: type,
      title: title,
      message: message,
      payload: payload,
    });
    
    return this.notificationsRepository.save(notification);
  }
  // Получить все уведомления пользователя
  async getUserNotifications(userId: number) {
    return this.notificationsRepository.find({
      where: { userId },
      order: { createdAt: 'DESC' },
    });
  }

  // Отметить как прочитанное
  async markAsRead(id: number) {
    await this.notificationsRepository.update(id, { isRead: true });
    return { message: 'Уведомление прочитано' };
  }
}