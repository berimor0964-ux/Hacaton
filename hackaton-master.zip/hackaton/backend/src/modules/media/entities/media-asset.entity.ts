import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    ManyToOne,
    JoinColumn,
    CreateDateColumn,
  } from 'typeorm';
  
  @Entity('media_assets')
  export class MediaAsset {
    @PrimaryGeneratedColumn()
    id: number;
  
    @Column()
    eventId: number;
  
    @Column()
    uploadedById: number;
  
    @Column()
    originalName: string; // Оригинальное имя файла (video.mp4)
  
    @Column()
    filename: string; // Имя файла на диске (случайная строка, чтобы не было конфликтов)
  
    @Column()
    mimeType: string; // video/mp4, audio/mp3 и т.д.
  
    @Column()
    size: number; // Размер в байтах
  
    @Column()
    url: string; // Ссылка для скачивания/просмотра (например, /uploads/123-456.mp4)
  
    @Column({ type: 'enum', enum: ['video', 'audio', 'image', 'document'], default: 'video' })
    type: string;
  
    @CreateDateColumn()
    createdAt: Date;
  
    // 👇 Связи (используем строки для избежания циклических зависимостей)
    @ManyToOne('Event', { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'eventId' })
    event: any;
  }