import {
  Controller,
  Post,
  Param,
  UseInterceptors,
  UploadedFile,
  ParseIntPipe,
  Get,
  BadRequestException,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname } from 'path';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { MediaAsset } from './entities/media-asset.entity.js';

@Controller('events/:eventId/media')
export class MediaController {
  constructor(
    @InjectRepository(MediaAsset)
    private readonly mediaRepository: Repository<MediaAsset>,
  ) {}

  // 👇 1. ЗАГРУЗКА ФАЙЛА
  @Post()
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({
        destination: './uploads', // Папка, куда сохраняем
        filename: (req, file, callback) => {
          // Генерируем уникальное имя: randomName + расширение
          const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
          const ext = extname(file.originalname);
          callback(null, `${uniqueSuffix}${ext}`);
        },
      }),
      limits: {
        fileSize: 1024 * 1024 * 500, // Максимальный размер файла: 500 МБ
      },
    }),
  )
  async uploadMedia(
    @Param('eventId', ParseIntPipe) eventId: number,
    @UploadedFile() file: Express.Multer.File,
    // @Body() body: { uploadedById: number } // Пока захардкодим юзера
  ) {
    if (!file) {
      throw new BadRequestException('Файл не загружен');
    }

    // Определяем тип файла
    let type: string = 'video';
    if (file.mimetype.startsWith('audio/')) type = 'audio';
    if (file.mimetype.startsWith('image/')) type = 'image';
    if (file.mimetype === 'application/pdf' || file.mimetype === 'text/plain') type = 'document';

    const media = this.mediaRepository.create({
      eventId,
      uploadedById: 1, // TODO: Заменить на реального юзера из JWT
      originalName: file.originalname,
      filename: file.filename,
      mimeType: file.mimetype,
      size: file.size,
      url: `/uploads/${file.filename}`,
      type,
    });

    return this.mediaRepository.save(media);
  }

  // 👇 2. ПОЛУЧЕНИЕ СПИСКА ФАЙЛОВ СОБЫТИЯ
  @Get()
  async getEventMedia(@Param('eventId', ParseIntPipe) eventId: number) {
    return this.mediaRepository.find({
      where: { eventId },
      order: { createdAt: 'DESC' },
    });
  }
}