import { Injectable, NotFoundException, BadRequestException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { EditorialReview, ReviewStatus } from './entities/editorial-review.entity.js';
import { Project, ProjectStatus } from '../projects/entities/project.entity.js';
import { NotificationsService } from '../notifications/notifications.service.js';
import { NotificationType } from '../notifications/entities/notification.entity.js';
import { DataSource } from 'typeorm';

@Injectable()
export class EditorialService {
  constructor(
    @InjectRepository(EditorialReview)
    private readonly reviewsRepository: Repository<EditorialReview>,
    @InjectRepository(Project)
    private readonly projectsRepository: Repository<Project>,
    
    // 👇 2. Внедряем его в конструктор (private readonly)
    private readonly notificationsService: NotificationsService,
    
    private readonly dataSource: DataSource, 
  ) {}
  async submitReview(
    projectId: number,
    editorId: number,
    status: ReviewStatus,
    comments: any,
  ) {
    const project = await this.projectsRepository.findOne({ where: { id: projectId } });
    if (!project) throw new NotFoundException('Проект не найден');

    // Создаем запись ревью
    const review = this.reviewsRepository.create({
      projectId,
      editorId,
      status,
      comments,
    });
    await this.reviewsRepository.save(review);

    // Меняем статус проекта в зависимости от решения редактора
    if (status === ReviewStatus.APPROVED) {
      project.status = ProjectStatus.DONE;
    } else if (status === ReviewStatus.TO_MONTAGE) {
      project.status = ProjectStatus.REWORK; // На доработку монтажеру
    } else if (status === ReviewStatus.TO_REPORTER) {
      project.status = ProjectStatus.REWORK; // На доработку репортеру
    }

    await this.projectsRepository.save(project);
    if (status === ReviewStatus.TO_MONTAGE) {
      await this.notificationsService.create(
        project.montageUserId,
        NotificationType.REWORK,
        'Проект возвращен на доработку',
        `Редактор оставил комментарии к проекту #${projectId}`,
        { projectId }
      );
    }
    return review;
  }

  async getReviewsForProject(projectId: number, currentUserId: number) {
    // 1. Получаем проект, чтобы знать, кто его монтажер
    const project = await this.projectsRepository.findOne({ where: { id: projectId } });
    if (!project) throw new NotFoundException('Проект не найден');

    // 2. Получаем роль текущего пользователя
    const userRoles = await this.dataSource.query(
      `SELECT r.name as role FROM users u
       JOIN user_roles ur ON u.id = ur.userId
       JOIN roles r ON r.id = ur.roleId
       WHERE u.id = $1`,
      [currentUserId]
    );
    const role = userRoles.length > 0 ? userRoles[0].role : 'unknown';

    // 3. ПРОВЕРКА ДЛЯ МОНТАЖЕРА
    if (role === 'montage') {
      if (project.montageUserId !== currentUserId) {
        throw new ForbiddenException('Вы можете смотреть историю только своих проектов');
      }
    }

    // 4. ПРОВЕРКА ДЛЯ РЕПОРТЕРА
    if (role === 'reporter') {
      // Идем в таблицу сюжетов, чтобы узнать, кто автор
      const story = await this.dataSource.query(
        `SELECT authorId FROM stories WHERE id = $1`,
        [project.storyId]
      );
      
      if (story.length === 0 || story[0].authorId !== currentUserId) {
        throw new ForbiddenException('Вы можете смотреть историю только своих сюжетов');
      }
    }
}}