import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EditorialReview } from './entities/editorial-review.entity.js';
import { Project } from '../projects/entities/project.entity.js';
import { NotificationsModule } from '../notifications/notifications.module.js';
import { EditorialController } from './editorial.controller.js';
import { EditorialService } from './editorial.service.js';
import { DataSource } from 'typeorm';

@Module({
  imports: [
    TypeOrmModule.forFeature([EditorialReview, Project]),
    NotificationsModule, 
  ],
  controllers: [EditorialController],
  providers: [EditorialService, 
  ],
})
export class EditorialModule {}