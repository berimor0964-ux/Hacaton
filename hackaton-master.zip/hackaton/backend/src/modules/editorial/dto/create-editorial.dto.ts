export class CreateEditorialDto {}
