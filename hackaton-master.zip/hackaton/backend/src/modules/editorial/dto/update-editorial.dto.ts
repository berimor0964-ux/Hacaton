import { PartialType } from '@nestjs/mapped-types';
import { CreateEditorialDto } from './create-editorial.dto.js';

export class UpdateEditorialDto extends PartialType(CreateEditorialDto) {}
