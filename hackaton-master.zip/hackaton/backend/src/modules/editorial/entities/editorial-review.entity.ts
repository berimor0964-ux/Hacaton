import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

export enum ReviewStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  TO_MONTAGE = 'to_montage', // Вернуть монтажеру
  TO_REPORTER = 'to_reporter', // Вернуть репортеру
}

@Entity('editorial_reviews')
export class EditorialReview {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  projectId: number;

  @Column()
  editorId: number;

  @Column({ type: 'enum', enum: ReviewStatus, default: ReviewStatus.PENDING })
  status: ReviewStatus;

  // Комментарии с тайм-кодами (например, JSON строка: [{"time": 15, "text": "убрать паузу"}])
  @Column({ type: 'jsonb', nullable: true })
  comments: any;

  @CreateDateColumn()
  createdAt: Date;
}