import { Controller, Post, Body, Param, ParseIntPipe, Get, Headers, ForbiddenException } from '@nestjs/common';
import { EditorialService } from './editorial.service.js';
import { ReviewStatus } from './entities/editorial-review.entity.js';
import { Roles } from '../../common/guards/roles.guard.js';

@Controller('editorial')
export class EditorialController {
  constructor(private readonly editorialService: EditorialService) {}

  // Редактор отправляет ревью
  @Roles('admin', 'director', 'editor')
  @Post('projects/:projectId/review')
  submitReview(
    @Param('projectId', ParseIntPipe) projectId: number,
    @Body() body: { editorId: number; status: ReviewStatus; comments: any },
  ) {
    return this.editorialService.submitReview(
      projectId,
      body.editorId,
      body.status,
      body.comments,
    );
  }

  // Получить все ревью для проекта (история правок)
  @Roles('admin', 'director', 'editor', 'reporter', 'montage')
  getReviews(
    @Param('projectId', ParseIntPipe) projectId: number,
    @Headers('x-user-id') userIdStr: string, // 👈 1. Получаем ID из заголовка
  ) {
    if (!userIdStr) {
      throw new ForbiddenException('Нет заголовка x-user-id');
    }
    const userId = parseInt(userIdStr, 10);

    // 👇 2. Передаем оба аргумента
    return this.editorialService.getReviewsForProject(projectId, userId);
  }
}