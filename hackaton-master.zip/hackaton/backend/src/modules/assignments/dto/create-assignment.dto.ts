export class CreateAssignmentDto {}
