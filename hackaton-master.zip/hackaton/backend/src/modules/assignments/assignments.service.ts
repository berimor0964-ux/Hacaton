import { Injectable, NotFoundException, BadRequestException, ConflictException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Not, Between, LessThanOrEqual, MoreThanOrEqual } from 'typeorm';
import { Assignment, AssignmentStatus } from './entities/assignment.entity.js';
import { UserAvailability } from '../users/entities/user-availability.entity.js';
import { Event } from '../events/entities/event.entity.js';

@Injectable()
export class AssignmentsService {
  constructor(
    @InjectRepository(Assignment)
    private readonly assignmentsRepository: Repository<Assignment>,
    @InjectRepository(Event)
    private readonly eventsRepository: Repository<Event>,
    @InjectRepository(UserAvailability)
    private readonly availabilityRepository: Repository<UserAvailability>,
  ) {}
  async findByEvent(eventId: number) {
    return this.assignmentsRepository.find({
      where: { eventId },
      relations: { user: true, role: true }, // Подтягиваем имена и роли
    });
  }

  async createAssignment(eventId: number, userId: number, roleId: number) {
    // 1. Проверяем, существует ли событие
    const event = await this.eventsRepository.findOne({ where: { id: eventId } });
    if (!event) throw new NotFoundException('Событие не найдено');

    // 2. ПРОВЕРКА НА ЗАНЯТОСТЬ (Пересечение дат)
    // Ищем в графике доступности пользователя записи, которые пересекаются с датами события
    const isBusy = await this.availabilityRepository.findOne({
      where: {
        userId,
        dateStart: LessThanOrEqual(event.dateEnd), // Начало занятости раньше конца события
        dateEnd: MoreThanOrEqual(event.dateStart), // Конец занятости позже начала события
      },
    });

    if (isBusy) {
      throw new ConflictException(`Пользователь занят в эти даты. Причина: ${isBusy.note || 'нет заметки'}`);
    }

    // 3. ПРОВЕРКА ДЛЯ РЕПОРТЕРОВ (Не более 3 событий)
    // В ТЗ: "Репортеров можно прикрепить на не более чем 3 события"
    // Мы считаем только активные назначения (pending и accepted)
    if (roleId === 1) { // ID 1 - это role 'reporter' (проверь свою БД)
      const activeAssignmentsCount = await this.assignmentsRepository.count({
        where: {
          userId,
          roleId,
          status: Not(AssignmentStatus.DONE), // Не считаем завершенные
        },
      });

      if (activeAssignmentsCount >= 3) {
        throw new BadRequestException('Репортер уже назначен на 3 активных события. Лимит исчерпан.');
      }
    }

    // 4. ПРОВЕРКА НА ДУБЛИКАТ
    // Нельзя назначить одного и того же человека на одно событие дважды с одной ролью
    const existingAssignment = await this.assignmentsRepository.findOne({
      where: { eventId, userId, roleId }
    });
    if (existingAssignment) {
       throw new ConflictException('Этот пользователь уже назначен на данное событие с этой ролью');
    }

    // 5. Создаем назначение
    const assignment = this.assignmentsRepository.create({
      eventId,
      userId,
      roleId,
      status: AssignmentStatus.PENDING,
    });

    return this.assignmentsRepository.save(assignment);
  }

  async updateStatus(assignmentId: number, currentUserId: number, currentUserRole: string) {
    // 1. Находим назначение
    const assignment = await this.assignmentsRepository.findOne({ 
      where: { id: assignmentId } 
    });

    if (!assignment) {
      throw new NotFoundException('Назначение не найдено');
    }
     // 2. Проверяем права (Логика "👤" из таблицы)
    // Если это не админ и не директор, то менять статус может только сам владелец
    if (currentUserRole !== 'admin' && currentUserRole !== 'director') {
      if (assignment.userId !== currentUserId) {
        throw new ForbiddenException('Вы можете менять статус только своих назначений');
      }
    }

    // 3. Меняем статус на DONE
    assignment.status = AssignmentStatus.DONE;
    return this.assignmentsRepository.save(assignment);
  }

  async remove(id: number) {
    const assignment = await this.assignmentsRepository.findOneBy({ id });
    if (!assignment) {
      throw new NotFoundException('Назначение не найдено');
    }
    return this.assignmentsRepository.remove(assignment);
  }
}