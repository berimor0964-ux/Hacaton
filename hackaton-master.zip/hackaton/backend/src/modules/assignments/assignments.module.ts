import { Module } from '@nestjs/common';
import { AssignmentsService } from './assignments.service.js';
import { AssignmentsController } from './assignments.controller.js';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Assignment } from './entities/assignment.entity.js';
import { UserAvailability } from '../users/entities/user-availability.entity.js';
import { Event } from '../events/entities/event.entity.js';

@Module({
  imports: [
    // 👇 Регистрируем их для этого модуля
    TypeOrmModule.forFeature([
      Assignment, 
      Event, 
      UserAvailability
    ]),
  ],
  controllers: [AssignmentsController],
  providers: [AssignmentsService],
  exports: [AssignmentsService],
})
export class AssignmentsModule {}
