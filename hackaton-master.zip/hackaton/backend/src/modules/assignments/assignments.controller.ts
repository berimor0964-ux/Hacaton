import { Controller, Post, Body, Param, ParseIntPipe, Patch, Headers, ForbiddenException, Get, Delete } from '@nestjs/common';
import { AssignmentsService } from './assignments.service.js';
import { DataSource } from 'typeorm';
import { Roles } from '../../common/guards/roles.guard.js';

@Controller('assignments')
export class AssignmentsController {
  constructor(
    private readonly assignmentsService: AssignmentsService,
    private readonly dataSource: DataSource, // 👈 Для получения роли
  ) {}
  @Get('event/:eventId')
findByEvent(@Param('eventId') eventId: string) {
  return this.assignmentsService.findByEvent(+eventId);
}
  @Post(':eventId')
  create(
    @Param('eventId', ParseIntPipe) eventId: number,
    @Body() body: { userId: number; roleId: number },
  ) {
    return this.assignmentsService.createAssignment(eventId, body.userId, body.roleId);
  }
  @Roles('admin', 'director', 'reporter', 'operator', 'driver') // Монтажера нет в таблице
  @Patch(':id/status')
  async updateStatus(
    @Param('id', ParseIntPipe) id: number,
    @Headers('x-user-id') userIdStr: string,
  ) {
    if (!userIdStr) throw new ForbiddenException('Нет заголовка x-user-id');
    const userId = parseInt(userIdStr, 10);

    // Получаем роль текущего пользователя из БД
    const userRoles = await this.dataSource.query(
      `SELECT r.name as role FROM users u
       JOIN user_roles ur ON u.id = ur.userId
       JOIN roles r ON r.id = ur.roleId
       WHERE u.id = $1`,
      [userId]
    );
    
    const role = userRoles.length > 0 ? userRoles[0].role : 'unknown';

    return this.assignmentsService.updateStatus(id, userId, role);
  }
  @Delete(':id')
async remove(@Param('id') id: string) {
  return this.assignmentsService.remove(+id);
}
}