import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, CreateDateColumn } from 'typeorm';

export enum AssignmentStatus {
    PENDING = 'pending',
    ACCEPTED = 'accepted',
    DONE = 'done',
  }
  
  @Entity('event_assignments')
  export class Assignment {
    @PrimaryGeneratedColumn()
    id: number;
  
    @Column()
    eventId: number;
  
    @Column()
    userId: number;
  
    @Column()
    roleId: number;
  
    @Column({
      type: 'enum',
      enum: AssignmentStatus,
      default: AssignmentStatus.PENDING,
    })
    status: AssignmentStatus;
  
    @Column({ nullable: true })
    note: string;
  
    @CreateDateColumn()
    createdAt: Date;
  
    @ManyToOne('Event', 'assignments', { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'eventId' })
    event: any;
  
    @ManyToOne('User', { eager: true })
    @JoinColumn({ name: 'userId' })
    user: any;
  
    @ManyToOne('Role', { eager: true })
    @JoinColumn({ name: 'roleId' })
    role: any;
  }