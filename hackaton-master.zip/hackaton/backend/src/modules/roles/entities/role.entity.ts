import { Entity, PrimaryGeneratedColumn, Column, ManyToMany } from 'typeorm';
import { User } from '../../users/entities/user.entity.js';

@Entity('roles')
export class Role {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  name: string; // 'admin', 'director', 'editor', 'reporter', 'operator', 'driver', 'montage'

  // Связь многие-ко-многим (у одного юзера может быть несколько ролей, хотя в ТЗ скорее 1, но так гибче)
  @ManyToMany(() => User, (user) => user.roles)
  users: User[];
}