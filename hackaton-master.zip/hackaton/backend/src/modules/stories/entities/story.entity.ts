import { Entity, PrimaryGeneratedColumn, Column, OneToMany, CreateDateColumn } from 'typeorm';
import { StoryBlock } from './story-block.entity.js';

@Entity('stories')
export class Story {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ nullable: true })
  eventId: number; // Привязка к событию (может быть null)

  @Column()
  authorId: number; // Кто создал (репортер)

  @Column()
  title: string;

  @Column({ default: 'draft' })
  status: string; // draft, montage, review, approved

  @CreateDateColumn()
  createdAt: Date;

  // 👇 Связь с блоками
  @OneToMany(() => StoryBlock, (block: StoryBlock) => block.story, { cascade: true })
  blocks: StoryBlock[];
}