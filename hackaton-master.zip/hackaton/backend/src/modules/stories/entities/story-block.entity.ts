import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';

@Entity('story_blocks')
export class StoryBlock {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  storyId: number;

  // Тип блока: видео из расшифровки, текст "начитка" или просто комментарий
  @Column({ type: 'enum', enum: ['video', 'text', 'comment'], default: 'video' })
  type: string;

  @Column({ nullable: true })
  mediaAssetId: number; // ID видеоролика

  @Column({ type: 'float', nullable: true })
  startTime: number;

  @Column({ type: 'float', nullable: true })
  endTime: number;

  @Column({ type: 'text', nullable: true })
  content: string; // Текст (для начиток или комментариев)

  @Column({ default: 0 })
  orderIndex: number; // Порядок блока (для Drag & Drop)

  // 👇 Разрываем цикл строкой 'Story'
  @ManyToOne('Story', 'blocks', { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'storyId' })
  story: any;
}