export class CreateStoryDto {}
