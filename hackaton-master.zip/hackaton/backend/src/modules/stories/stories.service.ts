import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { StoryBlock } from './entities/story-block.entity.js';
import { Story } from './entities/story.entity.js';

@Injectable()
export class StoriesService {
  constructor(
    @InjectRepository(Story)
    private readonly storiesRepository: Repository<Story>,
    @InjectRepository(StoryBlock)
    private readonly blocksRepository: Repository<StoryBlock>,
  ) {}
  async findAll() {
    // Возвращаем все сюжеты, сортируя по ID (новые сверху)
    return this.storiesRepository.find({
      order: { id: 'DESC' },
      relations: { blocks: true } // Подтягиваем блоки, чтобы показать их количество
    });
  }


  async create(data: { title: string; authorId: number; eventId?: number }) {
    const story = this.storiesRepository.create(data);
    return this.storiesRepository.save(story);
  }

  async findOne(id: number) {
    const story = await this.storiesRepository.findOne({
      where: { id },
      relations: { blocks: true },
      order: { blocks: { orderIndex: 'ASC' } },
    });
    if (!story) throw new NotFoundException('Сюжет не найден');
    return story;
  }

  async addBlock(storyId: number, blockData: Partial<StoryBlock>) {
    const story = await this.findOne(storyId);
    
    if (blockData.orderIndex === undefined) {
      blockData.orderIndex = story.blocks.length;
    }

    const block = this.blocksRepository.create({
      ...blockData,
      storyId,
    });
    return this.blocksRepository.save(block);
  }

  async reorderBlocks(storyId: number, blockIds: number[]) {
    for (let i = 0; i < blockIds.length; i++) {
      await this.blocksRepository.update(
        { id: blockIds[i], storyId },
        { orderIndex: i },
      );
    }
    return { message: 'Порядок обновлен' };
  }

  async updateBlock(id: number, updateData: any) {
    const block = await this.blocksRepository.findOneBy({ id });
    if (!block) {
      throw new NotFoundException('Блок не найден');
    }
    
    // Обновляем только те поля, которые пришли
    await this.blocksRepository.update(id, updateData);
    return this.blocksRepository.findOneBy({ id });
  }

  async removeBlock(id: number) {
    const result = await this.blocksRepository.delete(id);
    if (result.affected === 0) {
      throw new NotFoundException('Блок не найден');
    }
    return { success: true };
  }

  async remove(id: number) {
    // Сначала удаляем все блоки, принадлежащие этому сюжету (каскадное удаление)
    await this.blocksRepository.delete({ storyId: id });
    
    // Затем удаляем сам сюжет
    const result = await this.storiesRepository.delete(id);
    if (result.affected === 0) {
      throw new NotFoundException('Сюжет не найден');
    }
    return { success: true };
  }
}