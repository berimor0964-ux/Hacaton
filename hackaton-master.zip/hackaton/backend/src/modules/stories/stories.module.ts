import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Story } from './entities/story.entity.js';
import { StoryBlock } from './entities/story-block.entity.js';
import { StoriesController } from './stories.controller.js';
import { StoriesService } from './stories.service.js';

@Module({
  imports: [TypeOrmModule.forFeature([Story, StoryBlock])],
  controllers: [StoriesController],
  providers: [StoriesService],
})
export class StoriesModule {}