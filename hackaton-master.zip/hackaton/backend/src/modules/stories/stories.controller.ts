import { Controller, Post, Body, Param, ParseIntPipe, Get, Patch, Delete } from '@nestjs/common';
import { StoriesService } from './stories.service.js';

@Controller('stories')
export class StoriesController {
  constructor(private readonly storiesService: StoriesService) {}

  @Get()
  findAll() {
    return this.storiesService.findAll();
  }

  @Post()
  create(@Body() body: { title: string; authorId: number; eventId?: number }) {
    return this.storiesService.create(body);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.storiesService.findOne(id);
  }

  @Post(':id/blocks')
  addBlock(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: any, 
  ) {
    return this.storiesService.addBlock(id, body);
  }

  @Patch(':id/reorder')
  reorder(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { blockIds: number[] },
  ) {
    return this.storiesService.reorderBlocks(id, body.blockIds);
  }

  @Patch('blocks/:id')
  updateBlock(@Param('id') id: string, @Body() updateData: any) {
    return this.storiesService.updateBlock(+id, updateData);
  }

  // Удаление блока
  @Delete('blocks/:id')
  removeBlock(@Param('id') id: string) {
    return this.storiesService.removeBlock(+id);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.storiesService.remove(+id);
  }
}