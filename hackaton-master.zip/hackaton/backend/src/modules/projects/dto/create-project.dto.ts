export class CreateProjectDto {}
