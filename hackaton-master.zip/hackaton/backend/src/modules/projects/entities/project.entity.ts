import { Entity, PrimaryGeneratedColumn, Column, OneToMany, CreateDateColumn } from 'typeorm';
import { Render } from './render.entity.js';

export enum ProjectStatus {
  ASSIGNED = 'assigned',     // Назначен монтажеру
  IN_WORK = 'in_work',       // В работе
  REVIEW = 'review',         // Отправлен редактору на проверку
  REWORK = 'rework',         // Возвращен на доработку
  DONE = 'done',             // Утвержден
}

@Entity('projects')
export class Project {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  storyId: number; // Ссылка на сюжет

  @Column()
  montageUserId: number; // Кто монтирует

  @Column()
  editorId: number; // Кто проверяет

  @Column({ type: 'enum', enum: ProjectStatus, default: ProjectStatus.ASSIGNED })
  status: ProjectStatus;

  @CreateDateColumn()
  createdAt: Date;

  // 👇 Связь с рендерами (готовыми файлами)
  @OneToMany(() => Render, (render: Render) => render.project, { cascade: true })
  renders: Render[];
}