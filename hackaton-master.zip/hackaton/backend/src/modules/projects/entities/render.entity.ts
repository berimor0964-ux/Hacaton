import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, CreateDateColumn } from 'typeorm';

@Entity('renders')
export class Render {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  projectId: number;

  @Column()
  videoUrl: string; // Ссылка на готовый файл

  @CreateDateColumn()
  createdAt: Date;

  // 👇 Разрываем цикл строкой 'Project'
  @ManyToOne('Project', 'renders', { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'projectId' })
  project: any;
}