import { Controller, Post, Body, Param, ParseIntPipe, Get, UseInterceptors, UploadedFile, BadRequestException } from '@nestjs/common';
import { ProjectsService } from './projects.service.js';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname } from 'path';

@Controller('projects')
export class ProjectsController {
  constructor(private readonly projectsService: ProjectsService) {}

  @Post()
  create(
    @Body() body: { storyId: number; montageUserId: number; editorId: number },
  ) {
    return this.projectsService.create(body);
  }

  // Получить все проекты монтажера (для его личного кабинета)
  @Get('montage/:montageUserId')
  findAllForMontage(@Param('montageUserId', ParseIntPipe) montageUserId: number) {
    return this.projectsService.findAllForMontageUser(montageUserId);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.projectsService.findOne(id);
  }

  @Post(':id/render')
  uploadRender(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { videoUrl: string },
  ) {
    return this.projectsService.uploadRender(id, body.videoUrl);
  }
  @Post(':id/render-upload')
  @UseInterceptors(FileInterceptor('file', {
    storage: diskStorage({
      destination: './uploads',
      filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
        cb(null, `render-${uniqueSuffix}${extname(file.originalname)}`);
      }
    })
  }))
  async uploadRenderFile(
    @Param('id', ParseIntPipe) id: number, 
    @UploadedFile() file: Express.Multer.File
  ) {
    if (!file) throw new BadRequestException('Файл не загружен');
    
    // Формируем URL (как мы делали для медиатеки)
    const videoUrl = `http://localhost:3000/uploads/${file.filename}`;
    
    // Передаем в ваш существующий сервис
    return this.projectsService.uploadRender(id, videoUrl);
  }
}