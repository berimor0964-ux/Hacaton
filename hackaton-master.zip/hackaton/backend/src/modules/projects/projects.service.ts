import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Not } from 'typeorm';
import { Project, ProjectStatus } from './entities/project.entity.js';
import { Render } from './entities/render.entity.js';

@Injectable()
export class ProjectsService {
  constructor(
    @InjectRepository(Project)
    private readonly projectsRepository: Repository<Project>,
    @InjectRepository(Render)
    private readonly rendersRepository: Repository<Render>,
  ) {}

  async create(data: { storyId: number; montageUserId: number; editorId: number }) {
    // 👇 Бизнес-логика: не более 5 активных проектов у монтажера
    const activeProjectsCount = await this.projectsRepository.count({
      where: {
        montageUserId: data.montageUserId,
        status: Not(ProjectStatus.DONE), 
      },
    });

    if (activeProjectsCount >= 5) {
      throw new BadRequestException('У монтажера уже 5 активных проектов. Лимит исчерпан.');
    }

    const project = this.projectsRepository.create({
      ...data,
      status: ProjectStatus.ASSIGNED,
    });

    return this.projectsRepository.save(project);
  }

  async findAllForMontageUser(montageUserId: number) {
    return this.projectsRepository.find({
      where: { montageUserId },
      relations: { renders: true },
      order: { createdAt: 'DESC' },
    });
  }

  async findOne(id: number) {
    const project = await this.projectsRepository.findOne({
      where: { id },
      relations: { renders: true },
    });
    if (!project) throw new NotFoundException('Проект не найден');
    return project;
  }

  // 📤 Монтажер загружает готовый ролик
  async uploadRender(projectId: number, videoUrl: string) {
    const project = await this.findOne(projectId);

    const render = this.rendersRepository.create({
      projectId,
      videoUrl,
    });

    // Меняем статус на "На ревью"
    project.status = ProjectStatus.REVIEW;
    await this.projectsRepository.save(project);

    return this.rendersRepository.save(render);
  }
}