import { Entity, PrimaryGeneratedColumn, Column, OneToOne, JoinColumn, OneToMany } from 'typeorm';
import { TranscriptSegment } from './transcript-segment.entity.js';

@Entity('transcripts')
export class Transcript {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  mediaAssetId: number;

  @Column({ type: 'text', nullable: true })
  fullText: string;

  @Column({ nullable: true })
  attachedFileName: string;

  @OneToOne('MediaAsset', { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'mediaAssetId' })
  mediaAsset: any;

  // 👇 Типизируем segment как TranscriptSegment
  @OneToMany(() => TranscriptSegment, (segment: TranscriptSegment) => segment.transcript, { cascade: true })
  segments: TranscriptSegment[];
}