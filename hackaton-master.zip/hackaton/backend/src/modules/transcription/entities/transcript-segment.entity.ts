import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
// 👇 Убираем импорт Transcript

@Entity('transcript_segments')
export class TranscriptSegment {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  transcriptId: number;

  @Column({ type: 'float' })
  startTime: number;

  @Column({ type: 'float' })
  endTime: number;

  @Column({ type: 'text' })
  text: string;

  // 👇 Используем строку 'Transcript' вместо класса
  @ManyToOne('Transcript', 'segments', { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'transcriptId' })
  transcript: any; // 👈 any, чтобы TypeScript не ругался
}