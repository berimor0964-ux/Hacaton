import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Transcript } from './entities/transcript.entity.js';
import { TranscriptSegment } from './entities/transcript-segment.entity.js';

@Injectable()
export class TranscriptionService {
  constructor(
    @InjectRepository(Transcript)
    private readonly transcriptRepository: Repository<Transcript>,
    @InjectRepository(TranscriptSegment)
    private readonly segmentRepository: Repository<TranscriptSegment>,
  ) {}

  async attachFile(mediaAssetId: number, filename: string) {
    let transcript = await this.transcriptRepository.findOne({ where: { mediaAssetId } });
    
    if (!transcript) {
      transcript = this.transcriptRepository.create({ mediaAssetId });
    }
    
    transcript.attachedFileName = filename;
    return this.transcriptRepository.save(transcript);
  }

  async saveSegments(mediaAssetId: number, segments: { startTime: number; endTime: number; text: string }[]) {
    let transcript = await this.transcriptRepository.findOne({ where: { mediaAssetId } });
    
    if (!transcript) {
      transcript = this.transcriptRepository.create({ mediaAssetId });
      transcript = await this.transcriptRepository.save(transcript);
    }

    // Удаляем старые сегменты, если они были
    await this.segmentRepository.delete({ transcriptId: transcript.id });

    // Создаем новые
    const newSegments = segments.map((seg) =>
      this.segmentRepository.create({
        transcriptId: transcript.id,
        startTime: seg.startTime,
        endTime: seg.endTime,
        text: seg.text,
      }),
    );

    await this.segmentRepository.save(newSegments);

    // Обновляем полный текст
    transcript.fullText = segments.map((s) => s.text).join(' ');
    return this.transcriptRepository.save(transcript);
  }
}