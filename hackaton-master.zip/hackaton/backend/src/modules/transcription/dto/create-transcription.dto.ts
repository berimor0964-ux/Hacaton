export class CreateTranscriptionDto {}
