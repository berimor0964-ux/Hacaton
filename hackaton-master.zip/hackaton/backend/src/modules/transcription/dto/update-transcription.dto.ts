import { PartialType } from '@nestjs/mapped-types';
import { CreateTranscriptionDto } from './create-transcription.dto.js';

export class UpdateTranscriptionDto extends PartialType(CreateTranscriptionDto) {}
