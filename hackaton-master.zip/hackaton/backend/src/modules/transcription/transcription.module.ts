import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Transcript } from './entities/transcript.entity.js';
import { TranscriptSegment } from './entities/transcript-segment.entity.js';
import { TranscriptionController } from './transcription.controller.js';
import { TranscriptionService } from './transcription.service.js';

@Module({
  imports: [
    TypeOrmModule.forFeature([Transcript, TranscriptSegment]),
  ],
  controllers: [TranscriptionController],
  providers: [TranscriptionService],
  exports: [TranscriptionService],
})
export class TranscriptionModule {}