import { Controller, Post, Param, Body, ParseIntPipe, Get, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TranscriptionService } from './transcription.service.js';
import { Transcript } from './entities/transcript.entity.js';

@Controller('transcription')
export class TranscriptionController {
  constructor(
    private readonly transcriptionService: TranscriptionService,
    @InjectRepository(Transcript)
    private readonly transcriptRepository: Repository<Transcript>,
  ) {}

  @Post(':mediaAssetId/segments')
  async saveSegments(
    @Param('mediaAssetId', ParseIntPipe) mediaAssetId: number,
    @Body() body: { segments: { startTime: number; endTime: number; text: string }[] },
  ) {
    return this.transcriptionService.saveSegments(mediaAssetId, body.segments);
  }

  @Get(':mediaAssetId')
  async getTranscript(@Param('mediaAssetId', ParseIntPipe) mediaAssetId: number) {
    const transcript = await this.transcriptRepository.findOne({
      where: { mediaAssetId },
      relations: { segments: true }, // 👈 Исправили на объект
      order: { segments: { startTime: 'ASC' } },
    });

    if (!transcript) {
      throw new NotFoundException('Расшифровка для этого файла не найдена');
    }
    return transcript;
  }
}