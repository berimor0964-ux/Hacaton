<script>
    import { auth } from '../lib/auth.svelte.js';
    import { router, routes } from '../lib/router.svelte.js';
  
    const visible = $derived(
      Object.entries(routes).filter(([key, cfg]) => {
        if (key === 'login') return false;
        if (!cfg.roles) return true;
        return auth.hasRole(...cfg.roles);
      })
    );
  </script>
  
  <aside class="w-64 shrink-0 bg-white border-r border-slate-200 flex flex-col">
    <div class="h-16 flex items-center px-5 border-b border-slate-200">
      <div class="flex items-center gap-2">
        <div class="w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center text-white font-bold">Т</div>
        <div class="font-semibold text-slate-800">ТелеПрод</div>
      </div>
    </div>
  
    <nav class="flex-1 p-3 space-y-1 overflow-y-auto">
      {#each visible as [key, cfg] (key)}
        <button
          onclick={() => router.navigate(key)}
          class="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition
                 {router.page === key
                   ? 'bg-brand-50 text-brand-700'
                   : 'text-slate-600 hover:bg-slate-100'}"
        >
          <span class="text-base">{cfg.icon}</span>
          {cfg.label}
        </button>
      {/each}
    </nav>
  
    <div class="p-3 border-t border-slate-200 text-xs text-slate-400">
      v0.1 · MVP
    </div>
  </aside>