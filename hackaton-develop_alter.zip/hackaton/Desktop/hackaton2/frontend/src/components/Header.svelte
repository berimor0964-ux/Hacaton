<script>
    import { auth } from '../lib/auth.svelte.js';
    import { router } from '../lib/router.svelte.js';
    import Button from '../lib/ui/Button.svelte';
  
    const roleLabel = $derived(
      (auth.user?.roles ?? []).map(r => r.name).join(', ') || '—'
    );
  
    function logout() {
      auth.logout();
      router.navigate('login');
    }
  </script>
  
  <header class="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6">
    <div class="text-sm text-slate-500">
      {auth.user ? `Роль: ${roleLabel}` : ''}
    </div>
  
    {#if auth.user}
      <div class="flex items-center gap-4">
        <div class="text-right">
          <div class="text-sm font-medium text-slate-800">{auth.user.name}</div>
          <div class="text-xs text-slate-500">{auth.user.email}</div>
        </div>
        <div class="w-10 h-10 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center font-semibold">
          {auth.user.name?.[0]?.toUpperCase() ?? '?'}
        </div>
        <Button variant="ghost" size="sm" onclick={logout}>Выйти</Button>
      </div>
    {/if}
  </header>