<script>
    import { onMount } from 'svelte';
    import { apiFetch } from '../lib/api.js';
    import { auth } from '../lib/auth.svelte.js';
    import Card from '../lib/ui/Card.svelte';
    import Button from '../lib/ui/Button.svelte';
    import Select from '../lib/ui/Select.svelte';
    import Badge from '../lib/ui/Badge.svelte';
  
    let events = $state([]);
    let users = $state([]);
    let roles = $state([]);
    let loading = $state(true);
    let error = $state('');
  
    let selectedEventId = $state('');
    let selectedUserId = $state('');
    let selectedRoleId = $state('');
    let isSubmitting = $state(false);
  
    let currentAssignments = $state([]);
    let assignmentsLoading = $state(false);
  
    const canAssign = $derived(auth.hasRole('admin', 'director', 'editor'));
  
    onMount(async () => {
      if (!canAssign) return;
      try {
        const [evts, usrs, rls] = await Promise.all([
          apiFetch('/events'),
          apiFetch('/users'),
          apiFetch('/roles')
        ]);
        events = evts;
        users = usrs;
        roles = rls;
      } catch (e) {
        error = `Ошибка загрузки данных: ${e.message}`;
      } finally {
        loading = false;
      }
    });
  
    $effect(() => {
      if (selectedEventId) {
        loadAssignments(selectedEventId);
      } else {
        currentAssignments = [];
      }
    });
  
    async function loadAssignments(eventId) {
      assignmentsLoading = true;
      try {
        currentAssignments = await apiFetch(`/assignments/event/${eventId}`);
      } catch (e) {
        console.error(e);
        currentAssignments = [];
      } finally {
        assignmentsLoading = false;
      }
    }
  
    const eventOptions = $derived(events.map(e => ({ value: e.id, label: e.title })));
    const userOptions = $derived(users.map(u => ({ value: u.id, label: `${u.name} (${u.email})` })));
    const roleOptions = $derived(roles.map(r => ({ value: r.id, label: r.name })));
  
    async function assignUser(e) {
      e.preventDefault();
      if (!selectedEventId || !selectedUserId || !selectedRoleId) return;
      
      isSubmitting = true;
      error = '';
      try {
        await apiFetch(`/assignments/${selectedEventId}`, {
          method: 'POST',
          body: JSON.stringify({
            userId: Number(selectedUserId),
            roleId: Number(selectedRoleId),
          }),
        });
        
        selectedUserId = '';
        selectedRoleId = '';
        await loadAssignments(selectedEventId);
      } catch (e) {
        error = e.message;
      } finally {
        isSubmitting = false;
      }
    }
  
    async function removeAssignment(id) {
      if (!confirm('Снять сотрудника с этого события?')) return;
      try {
        await apiFetch(`/assignments/${id}`, { method: 'DELETE' });
        await loadAssignments(selectedEventId);
      } catch (e) {
        alert('Ошибка удаления: ' + e.message);
      }
    }
  
    function getStatusLabel(status) {
      if (status === 'pending') return 'Ожидает';
      if (status === 'accepted') return 'Принято';
      if (status === 'done') return 'Выполнено';
      return status;
    }
  
    function getStatusTone(status) {
      if (status === 'pending') return 'amber';
      if (status === 'accepted') return 'blue';
      if (status === 'done') return 'green';
      return 'slate';
    }
  </script>
  
  <div class="max-w-4xl mx-auto space-y-6">
    <div>
      <h1 class="text-2xl font-semibold text-slate-800">Назначения</h1>
      <p class="text-sm text-slate-500 mt-1">Распределение команды на события</p>
    </div>
  
    {#if !canAssign}
      <Card>
        <div class="text-center py-8 text-slate-500">У вас нет прав для управления назначениями.</div>
      </Card>
    {:else if loading}
      <div class="text-center py-10 text-slate-400">Загрузка данных...</div>
    {:else}
      {#if error}
        <div class="p-4 bg-rose-50 text-rose-700 rounded-xl text-sm border border-rose-200">{error}</div>
      {/if}
  
      <!-- ФОРМА НАЗНАЧЕНИЯ -->
      <Card title="Назначить на событие">
        <form onsubmit={assignUser} class="space-y-5">
          <Select 
            label="Выберите событие" 
            bind:value={selectedEventId} 
            options={eventOptions} 
            placeholder="-- Выберите событие --" 
            required 
          />
          
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select label="Сотрудник" bind:value={selectedUserId} options={userOptions} placeholder="-- Кто нужен? --" required />
            <Select label="Роль на событии" bind:value={selectedRoleId} options={roleOptions} placeholder="-- Кем будет? --" required />
          </div>
  
          <Button type="submit" disabled={isSubmitting} class="w-full md:w-auto">
            {isSubmitting ? 'Назначаем...' : '+ Назначить сотрудника'}
          </Button>
        </form>
      </Card>
  
      <!-- БЛОК КОМАНДЫ -->
      {#if selectedEventId}
        <div class="mt-8">
          <h2 class="text-lg font-semibold text-slate-800 mb-3 flex items-center gap-2">
            Команда на событии
            <span class="bg-slate-200 text-slate-600 text-xs py-0.5 px-2 rounded-full">
              {currentAssignments.length}
            </span>
          </h2>
          
          {#if assignmentsLoading}
            <Card><div class="text-center text-sm text-slate-400 py-4">Загрузка команды...</div></Card>
          {:else if currentAssignments.length === 0}
            <Card>
              <div class="text-center text-sm text-slate-500 py-8">
                На это событие еще никого не назначили.<br/>
                Используйте форму выше, чтобы добавить первого сотрудника.
              </div>
            </Card>
          {:else}
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
              {#each currentAssignments as assignment}
                <div class="bg-white rounded-2xl border border-slate-200 p-4 flex items-center justify-between shadow-sm hover:shadow-md transition">
                  <div class="flex items-center gap-4">
                    <!-- Аватарка -->
                    <div class="w-12 h-12 rounded-full bg-brand-50 text-brand-600 flex items-center justify-center font-bold text-lg border border-brand-100">
                      {assignment.user?.name?.[0]?.toUpperCase() || '?'}
                    </div>
                    
                    <!-- Инфо -->
                    <div>
                      <div class="font-medium text-slate-800">{assignment.user?.name || 'Неизвестный'}</div>
                      <div class="flex items-center gap-2 mt-1">
                        <Badge tone="brand">{assignment.role?.name || 'Роль не указана'}</Badge>
                        <Badge tone={getStatusTone(assignment.status)}>{getStatusLabel(assignment.status)}</Badge>
                      </div>
                    </div>
                  </div>
  
                  <!-- Удаление -->
                  <button 
                    onclick={() => removeAssignment(assignment.id)}
                    class="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                    title="Снять с события"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                  </button>
                </div>
              {/each}
            </div>
          {/if}
        </div>
      {/if}
    {/if}
  </div>