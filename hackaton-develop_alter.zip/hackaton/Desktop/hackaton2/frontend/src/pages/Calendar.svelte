<script>
    import { onMount } from 'svelte';
    import { apiFetch } from '../lib/api.js';
    import { auth } from '../lib/auth.svelte.js';
    import Card from '../lib/ui/Card.svelte';
    import Button from '../lib/ui/Button.svelte';
    import Input from '../lib/ui/Input.svelte';
    import Badge from '../lib/ui/Badge.svelte';
  
    let currentDate = $state(new Date());
    let events = $state([]);
    let loading = $state(true);
    let selectedEvent = $state(null);
  
    // Состояние для создания
    let isCreating = $state(false);
    let createDate = $state(new Date());
    let newTitle = $state('');
    let newStart = $state('');
    let newEnd = $state('');
    let isSubmitting = $state(false);
  
    const canCreate = $derived(auth.hasRole('admin', 'director'));
  
    // Логика календаря
    const currentYear = $derived(currentDate.getFullYear());
    const currentMonth = $derived(currentDate.getMonth());
    
    const monthNames = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
    
    const daysInMonth = $derived(new Date(currentYear, currentMonth + 1, 0).getDate());
    const firstDayOfMonth = $derived(new Date(currentYear, currentMonth, 1).getDay());
    const startOffset = $derived(firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1);
  
    const daysArray = $derived(Array.from({ length: daysInMonth }, (_, i) => i + 1));
    const emptyDays = $derived(Array.from({ length: startOffset }, () => null));
  
    onMount(async () => {
      await loadEvents();
    });
  
    async function loadEvents() {
      loading = true;
      try {
        events = await apiFetch('/events');
      } catch (e) {
        console.error('Ошибка загрузки событий:', e);
      } finally {
        loading = false;
      }
    }
  
    function prevMonth() {
      currentDate = new Date(currentYear, currentMonth - 1, 1);
    }
  
    function nextMonth() {
      currentDate = new Date(currentYear, currentMonth + 1, 1);
    }
  
    function getEventsForDay(day) {
      if (!day) return [];
      return events.filter(e => {
        const d = new Date(e.dateStart);
        return d.getDate() === day && d.getMonth() === currentMonth && d.getFullYear() === currentYear;
      });
    }
  
    // Открытие модалки создания по двойному клику
    function handleDayDblClick(day) {
      if (!canCreate || !day) return;
      
      // Формируем дату для инпута (YYYY-MM-DDTHH:mm)
      const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}T12:00`;
      
      newStart = dateStr;
      newEnd = dateStr;
      newTitle = '';
      isCreating = true;
    }

    function handleDayContextMenu(e, day) {
    e.preventDefault(); 
    if (!canCreate || !day) return;
    
    const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}T12:00`;
    
    newStart = dateStr;
    newEnd = dateStr;
    newTitle = '';
    isCreating = true;
  }
  
    async function createEvent(e) {
      e.preventDefault();
      isSubmitting = true;
      try {
        const created = await apiFetch('/events', {
          method: 'POST',
          body: JSON.stringify({
            title: newTitle,
            dateStart: new Date(newStart).toISOString(),
            dateEnd: new Date(newEnd).toISOString(),
          }),
        });
        events = [...events, created];
        isCreating = false;
      } catch (e) {
        alert('Ошибка создания: ' + e.message);
      } finally {
        isSubmitting = false;
      }
    }
    async function deleteCalendarEvent(id) {
    if (!confirm('Вы уверены, что хотите удалить это событие?')) return;
    
    try {
      await apiFetch(`/events/${id}`, { method: 'DELETE' });
      // Убираем событие из массива и закрываем модалку
      events = events.filter(e => e.id !== id);
      selectedEvent = null;
    } catch (e) {
      alert('Ошибка удаления: ' + e.message);
    }
  }
  </script>
  
  <div class="max-w-6xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
      <div>
        <h1 class="text-2xl font-semibold text-slate-800">Календарь</h1>
        <p class="text-sm text-slate-500 mt-1">
          {canCreate ? 'Двойной клик по дню создает событие' : 'График съемок и эфиров'}
        </p>
      </div>
    </div>
  
    <Card padding="p-0">
      <div class="flex items-center justify-between p-4 border-b border-slate-200 bg-slate-50 rounded-t-2xl">
        <div class="flex items-center gap-4">
          <button onclick={prevMonth} class="p-2 hover:bg-white rounded-lg border border-transparent hover:border-slate-200 transition">←</button>
          <h2 class="text-lg font-semibold text-slate-800 w-40 text-center">
            {monthNames[currentMonth]} {currentYear}
          </h2>
          <button onclick={nextMonth} class="p-2 hover:bg-white rounded-lg border border-transparent hover:border-slate-200 transition">→</button>
        </div>
        <Button variant="ghost" onclick={() => currentDate = new Date()}>Сегодня</Button>
      </div>
  
      <div class="grid grid-cols-7 text-center py-2 bg-slate-50 border-b border-slate-200 text-sm font-medium text-slate-500">
        {#each ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'] as day}
          <div>{day}</div>
        {/each}
      </div>
  
      <div class="grid grid-cols-7 auto-rows-[120px]">
        {#each emptyDays as _}
          <div class="border-b border-r border-slate-100 bg-slate-50/50"></div>
        {/each}
  
        {#each daysArray as day}
          {@const dayEvents = getEventsForDay(day)}
          <div 
          class="border-b border-r border-slate-100 p-2 relative group hover:bg-slate-50 transition overflow-y-auto {canCreate ? 'cursor-pointer' : ''}"
          role="gridcell"
          tabindex="0"
          ondblclick={() => handleDayDblClick(day)}
          onkeydown={(e) => { if (e.key === 'Enter') handleDayDblClick(day); }}
          oncontextmenu={(e) => handleDayContextMenu(e, day)}
        >
            <span class="inline-flex items-center justify-center w-7 h-7 rounded-full text-sm font-medium mb-1
                         {new Date().getDate() === day && currentDate.getMonth() === new Date().getMonth() ? 'bg-brand-600 text-white' : 'text-slate-700'}">
              {day}
            </span>
            
            <div class="space-y-1 pointer-events-none">
              {#each dayEvents as ev}
                <!-- pointer-events-auto чтобы кнопка кликалась отдельно -->
                <button
                type="button"
                onclick={(e) => { e.stopPropagation(); selectedEvent = ev; }}
                class="w-full text-left px-2 py-1 rounded text-xs truncate transition pointer-events-auto
                       {ev.status === 'active' ? 'bg-amber-100 text-amber-800 hover:bg-amber-200' : 
                        ev.status === 'completed' ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200' : 
                        'bg-blue-100 text-blue-800 hover:bg-blue-200'}"
              >
                {ev.title}
              </button>
              {/each}
            </div>
          </div>
        {/each}
      </div>
    </Card>
  </div>
  
  <!-- Модалка: Создание -->
  {#if isCreating}
    <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
      <div class="bg-white rounded-2xl shadow-xl max-w-md w-full overflow-hidden">
        <form onsubmit={createEvent}>
          <div class="p-6">
            <h3 class="text-xl font-bold text-slate-800 mb-4">Новое событие</h3>
            <div class="space-y-4">
              <Input label="Название" bind:value={newTitle} placeholder="Например: Съемка репортажа" required />
              <Input label="Начало" type="datetime-local" bind:value={newStart} required />
              <Input label="Конец" type="datetime-local" bind:value={newEnd} required />
            </div>
          </div>
          <div class="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2">
            <Button variant="secondary" onclick={() => isCreating = false}>Отмена</Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Сохраняем...' : 'Создать'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  {/if}
  
  <!-- Модалка: Детали -->
  {#if selectedEvent}
  <div 
  class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm" 
  role="presentation"
  onclick={() => selectedEvent = null}
  onkeydown={(e) => { if (e.key === 'Escape') selectedEvent = null; }}
>
  <div 
    class="bg-white rounded-2xl shadow-xl max-w-md w-full overflow-hidden" 
    role="dialog"
    tabindex="-1"
    onclick={(e) => e.stopPropagation()}
    onkeydown={(e) => e.stopPropagation()}
  >
        <div class="p-6">
          <div class="flex justify-between items-start mb-4">
            <h3 class="text-xl font-bold text-slate-800">{selectedEvent.title}</h3>
            <button onclick={() => selectedEvent = null} class="text-slate-400 hover:text-slate-600">✕</button>
          </div>
          <div class="space-y-3 text-sm">
            <div>
              <span class="text-slate-500 block mb-1">Статус</span>
              <Badge tone={selectedEvent.status === 'active' ? 'amber' : selectedEvent.status === 'completed' ? 'green' : 'blue'}>
                {selectedEvent.status}
              </Badge>
            </div>
            <div>
              <span class="text-slate-500 block mb-1">Начало</span>
              <span class="font-medium text-slate-800">{new Date(selectedEvent.dateStart).toLocaleString('ru-RU')}</span>
            </div>
            <div>
              <span class="text-slate-500 block mb-1">Конец</span>
              <span class="font-medium text-slate-800">{new Date(selectedEvent.dateEnd).toLocaleString('ru-RU')}</span>
            </div>
          </div>
        </div>
        <div class="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
            {#if canCreate}
              <Button variant="danger" onclick={() => deleteCalendarEvent(selectedEvent.id)}>
                Удалить
              </Button>
            {:else}
              <div></div>
            {/if}
            <Button variant="secondary" onclick={() => selectedEvent = null}>Закрыть</Button>
          </div>
      </div>
    </div>
  {/if}