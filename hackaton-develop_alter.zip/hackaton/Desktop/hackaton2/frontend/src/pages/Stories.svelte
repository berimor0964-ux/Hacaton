<script>
    import { onMount } from 'svelte';
    import { apiFetch } from '../lib/api.js';
    import { auth } from '../lib/auth.svelte.js';
    import Card from '../lib/ui/Card.svelte';
    import Button from '../lib/ui/Button.svelte';
    import Input from '../lib/ui/Input.svelte';
    import Badge from '../lib/ui/Badge.svelte';
    import Select from '../lib/ui/Select.svelte';
  
    let stories = $state([]);
    let loading = $state(true);
    let error = $state('');
    let isAddingVideo = $state(false);
  let newVideoTitle = $state('');
  let newVideoUrl = $state('');
  let selectedFile = $state(null);
  let isUploading = $state(false);
  let uploadMode = $state('file'); // По умолчанию теперь загрузка с компа
  
    // Состояние конструктора
    let activeStory = $state(null);
    let blocks = $state([]);
    let isCreatingStory = $state(false);
    let newStoryTitle = $state('');
    let editingBlockId = $state(null);
    let editingContent = $state('');
    let events = $state([]); // Список событий для выбора
  let selectedEventId = $state(''); // Куда загружаем
    
    // Состояние для Drag-and-Drop
    let draggedItem = $state(null);
    
    // Доступные блоки (в MVP просто захардкодим, в реальности — из /events/:id/media)
    let availableBlocks = $state([
    { id: 'text-1', type: 'text', title: 'Текст ведущего', content: 'Здравствуйте, в эфире...' },
    { id: 'text-2', type: 'text', title: 'Стендап', content: 'Я нахожусь на месте событий...' },
    { id: 'video-1', type: 'video', title: 'Видео: Общий план', url: 'https://example.com/video1.mp4' },
    { id: 'video-2', type: 'video', title: 'Видео: Интервью', url: 'https://example.com/video2.mp4' },
  ]);
    onMount(async () => {
      await loadStories();
      try {
      events = await apiFetch('/events');
    } catch (e) {
      console.error('Не удалось загрузить события', e);
    }
  });
  
    async function loadStories() {
      loading = true;
      try {
        stories = await apiFetch('/stories');
      } catch (e) {
        error = `Ошибка загрузки сюжетов: ${e.message}`;
      } finally {
        loading = false;
      }
    }
    function startEditing(block) {
    editingBlockId = block.id;
    editingContent = block.content || '';
  }

  async function saveBlockContent(blockId) {
    try {
      // ВНИМАНИЕ: Проверьте URL на бэкенде! 
      // Возможно, у вас PATCH /stories/blocks/:id или PATCH /stories/:storyId/blocks/:blockId
      await apiFetch(`/stories/blocks/${blockId}`, {
        method: 'PATCH',
        body: JSON.stringify({ content: editingContent }),
      });
      
      // Обновляем локально, чтобы не перезагружать страницу
      blocks = blocks.map(b => b.id === blockId ? { ...b, content: editingContent } : b);
      editingBlockId = null;
    } catch (e) {
      alert('Ошибка сохранения: ' + e.message);
    }
  }

  async function deleteBlock(blockId) {
    if (!confirm('Удалить этот блок?')) return;
    try {
      await apiFetch(`/stories/blocks/${blockId}`, { method: 'DELETE' });
      blocks = blocks.filter(b => b.id !== blockId);
    } catch (e) {
      alert('Ошибка удаления: ' + e.message);
    }
  }
  
    async function openStory(storyId) {
      try {
        const fullStory = await apiFetch(`/stories/${storyId}`);
        activeStory = fullStory;
        // Сортируем блоки по orderIndex
        blocks = [...(fullStory.blocks || [])].sort((a, b) => a.orderIndex - b.orderIndex);
      } catch (e) {
        alert('Не удалось открыть сюжет: ' + e.message);
      }
    }
  
    function closeConstructor() {
      activeStory = null;
      blocks = [];
    }
  
    async function createStory(e) {
    e.preventDefault();
    try {
      const currentUserId = auth.user?.id || 1; // Берем ID текущего юзера
      
      const created = await apiFetch('/stories', {
        method: 'POST',
        body: JSON.stringify({ 
          title: newStoryTitle, 
          status: 'draft',
          authorId: currentUserId // <--- ДОБАВЛЯЕМ АВТОРА
        }),
      });
      stories = [created, ...stories];
      isCreatingStory = false;
      newStoryTitle = '';
      await openStory(created.id);
    } catch (e) {
      alert('Ошибка создания: ' + e.message);
    }
  }
  
    // === DRAG AND DROP ЛОГИКА ===
  
    function handleDragStart(event, item, isAvailable) {
      draggedItem = { ...item, isAvailable };
      event.dataTransfer.effectAllowed = 'copyMove';
      // Для визуального эффекта
      event.target.classList.add('opacity-50');
    }
  
    function handleDragEnd(event) {
      event.target.classList.remove('opacity-50');
      draggedItem = null;
    }
  
    function handleDragOver(event) {
      event.preventDefault(); // Разрешаем дроп
      event.dataTransfer.dropEffect = draggedItem?.isAvailable ? 'copy' : 'move';
    }
  
    async function handleDrop(event) {
    event.preventDefault();
    if (!draggedItem) return;

    if (draggedItem.isAvailable) {
      // Для видео берем url, для текста — content
      const blockContent = draggedItem.type === 'video' ? draggedItem.url : draggedItem.content;
      
      const newBlock = {
        type: draggedItem.type,
        content: blockContent, // Сохраняем ссылку на видео в content
        mediaAssetId: null, 
        orderIndex: blocks.length,
      };
      
      try {
        const created = await apiFetch(`/stories/${activeStory.id}/blocks`, {
          method: 'POST',
          body: JSON.stringify(newBlock),
        });
        // Если бэкенд вернул блок без content (маловероятно), подстрахуемся
        if (!created.content) created.content = blockContent;
        
        blocks = [...blocks, created];
      } catch (e) {
        alert('Ошибка добавления блока: ' + e.message);
      }
    }
    
    draggedItem = null;
  }
    function handleFileChange(e) {
    selectedFile = e.target.files[0];
  }


  async function addVideoToLibrary(e) {
    e.preventDefault();
    
    if (uploadMode === 'file') {
      if (!selectedFile) return alert('Выберите файл');
      if (!selectedEventId) return alert('Выберите событие');
      
      isUploading = true;
      try {
        const formData = new FormData();
        formData.append('file', selectedFile);
        
        const response = await apiFetch(`/events/${selectedEventId}/media`, {
          method: 'POST',
          body: formData,
        });
        
        // Добавляем загруженный файл в медиатеку (обратите внимание: availableBlocks = ..., а не let)
        availableBlocks = [
          {
            id: `video-${response.id}`,
            type: 'video',
            title: newVideoTitle || response.originalName || selectedFile.name,
            url: `http://localhost:3000${response.url}`
          },
          ...availableBlocks
        ];
        
        // Сброс формы
        isAddingVideo = false;
        newVideoTitle = '';
        selectedFile = null;
        selectedEventId = '';
        uploadMode = 'file';
      } catch (err) {
        alert('Ошибка загрузки: ' + err.message);
      } finally {
        isUploading = false;
      }
    } else {
      // Добавление по ссылке
      if (!newVideoUrl.trim()) return;
      
      availableBlocks = [
        {
          id: `video-${Date.now()}`,
          type: 'video',
          title: newVideoTitle || 'Мое видео',
          url: newVideoUrl
        },
        ...availableBlocks
      ];
      
      isAddingVideo = false;
      newVideoTitle = '';
      newVideoUrl = '';
    }
  }

  async function deleteStory(id, e) {
    e.stopPropagation(); // Чтобы не открывался конструктор при клике на корзину
    if (!confirm('Вы уверены, что хотите удалить этот сюжет и все его блоки?')) return;
    
    try {
      await apiFetch(`/stories/${id}`, { method: 'DELETE' });
      stories = stories.filter(s => s.id !== id);
    } catch (e) {
      alert('Ошибка удаления: ' + e.message);
    }
  }
  </script>
  
  <div class="max-w-6xl mx-auto space-y-6">
    <!-- Заголовок и кнопка создания -->
    <div class="flex items-center justify-between">
      <div>
        <h1 class="text-2xl font-semibold text-slate-800">Сюжеты</h1>
        <p class="text-sm text-slate-500 mt-1">Управление и сборка видеоматериалов</p>
      </div>
      <Button onclick={() => isCreatingStory = true}>+ Новый сюжет</Button>
    </div>
  
    {#if error}
      <div class="p-4 bg-rose-50 text-rose-700 rounded-xl text-sm border border-rose-200">{error}</div>
    {/if}
  
    <!-- Модалка создания сюжета -->
    {#if isCreatingStory}
      <Card title="Новый сюжет">
        <form onsubmit={createStory} class="space-y-4">
          <Input label="Название сюжета" bind:value={newStoryTitle} placeholder="Например: Репортаж о погоде" required />
          <div class="flex gap-2">
            <Button type="submit">Создать</Button>
            <Button variant="secondary" onclick={() => isCreatingStory = false}>Отмена</Button>
          </div>
        </form>
      </Card>
    {/if}
  
    <!-- СПИСОК СЮЖЕТОВ -->
    {#if !activeStory}
      {#if loading}
        <div class="text-center py-10 text-slate-400">Загрузка...</div>
      {:else if stories.length === 0}
        <Card>
          <div class="text-center py-10 text-slate-500">
            Пока нет сюжетов. Создайте первый, чтобы начать сборку.
          </div>
        </Card>
      {:else}
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {#each stories as story}
          <!-- Внешний контейнер теперь DIV -->
          <div 
            onclick={() => openStory(story.id)}
            onkeydown={(e) => { if (e.key === 'Enter') openStory(story.id); }}
            role="button"
            tabindex="0"
            class="relative text-left bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition group flex flex-col h-full cursor-pointer"
          >
            <div class="flex justify-between items-start mb-2 w-full pointer-events-none">
              <Badge tone={story.status === 'approved' ? 'green' : story.status === 'review' ? 'amber' : 'slate'}>
                {story.status}
              </Badge>
              <span class="text-slate-300 group-hover:text-brand-500 transition">→</span>
            </div>
            
            <h3 class="font-semibold text-slate-800 text-lg mb-1 pointer-events-none">{story.title}</h3>
            <p class="text-xs text-slate-500 mt-auto pointer-events-none">Блоков: {story.blocks?.length || 0}</p>

            <!-- Кнопка удаления -->
            <button 
              onclick={(e) => deleteStory(story.id, e)}
              class="absolute bottom-4 right-4 p-2 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-lg opacity-0 group-hover:opacity-100 transition z-10"
              title="Удалить сюжет"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
            </button>
          </div>
        {/each}
      </div>
      {/if}
    {/if}
  
    <!-- КОНСТРУКТОР СЮЖЕТА -->
    {#if activeStory}
      <div class="flex items-center gap-4 mb-4">
        <Button variant="ghost" onclick={closeConstructor}>← Назад к списку</Button>
        <h2 class="text-xl font-bold text-slate-800">{activeStory.title}</h2>
      </div>
  
      <div class="flex gap-6 items-start">
        <!-- ЛЕВАЯ ПАНЕЛЬ: Доступные блоки -->
              <!-- ЛЕВАЯ ПАНЕЛЬ: Доступные блоки -->
      <Card title="Медиатека" padding="p-4" class="w-1/3 shrink-0">
        <div class="flex items-center justify-between mb-4">
          <p class="text-xs text-slate-500">Перетащите в полотно</p>
          <Button size="sm" variant="secondary" onclick={() => isAddingVideo = true}>
            + Видео
          </Button>
        </div>

        <div class="space-y-3">
          {#each availableBlocks as item (item.id)}
            <div 
              draggable="true"
              ondragstart={(e) => handleDragStart(e, item, true)}
              ondragend={handleDragEnd}
              class="bg-slate-50 border border-slate-200 p-3 rounded-lg cursor-grab active:cursor-grabbing hover:border-brand-300 transition"
            >
              <div class="flex items-center gap-2 mb-1">
                <span class="text-lg">{item.type === 'video' ? '🎬' : '📝'}</span>
                <span class="font-medium text-sm text-slate-800">{item.title}</span>
              </div>
              <p class="text-xs text-slate-500 line-clamp-2">{item.content || item.url}</p>
            </div>
          {/each}
        </div>
      </Card>
  
        <!-- ПРАВАЯ ПАНЕЛЬ: Полотно сюжета -->
        <div class="flex-1">
          <Card title="Полотно сюжета" padding="p-4">
            <div 
              class="min-h-[400px] border-2 border-dashed border-slate-300 rounded-xl p-4 bg-slate-50 flex flex-col gap-3"
              ondragover={handleDragOver}
              ondrop={handleDrop}
              role="region"
              aria-label="Полотно сюжета"
            >
              {#if blocks.length === 0}
                <div class="flex-1 flex items-center justify-center text-slate-400 text-sm">
                  Перетащите сюда блоки из медиатеки
                </div>
              {:else}
              {#each blocks as block, index}
              <div class="bg-white border border-slate-200 p-4 rounded-xl shadow-sm flex gap-4 items-start group">
                <div class="text-2xl pt-1">{block.type === 'video' ? '🎬' : '📝'}</div>
                
                <div class="flex-1">
                  <div class="flex justify-between items-center mb-2">
                    <span class="font-medium text-sm text-slate-800 capitalize">{block.type} блок</span>
                    <div class="flex items-center gap-2">
                      <span class="text-xs text-slate-400 bg-slate-100 px-2 py-0.5 rounded">#{index + 1}</span>
                      <button 
                        onclick={() => deleteBlock(block.id)}
                        class="text-slate-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition"
                        title="Удалить блок"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                      </button>
                    </div>
                  </div>

                  <!-- РЕДАКТИРОВАНИЕ ТЕКСТА (если нажали "Редактировать") -->
                  {#if editingBlockId === block.id && block.type === 'text'}
                    <div class="space-y-2">
                      <textarea 
                        bind:value={editingContent}
                        class="w-full p-2 border border-blue-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                        rows="3"
                      ></textarea>
                      <div class="flex gap-2">
                        <Button size="sm" onclick={() => saveBlockContent(block.id)}>Сохранить</Button>
                        <Button size="sm" variant="secondary" onclick={() => editingBlockId = null}>Отмена</Button>
                      </div>
                    </div>
                  
                  <!-- ОТОБРАЖЕНИЕ ВИДЕО -->
                  {:else if block.type === 'video'}
                    <div class="mt-2 bg-slate-900 rounded-lg overflow-hidden relative aspect-video flex items-center justify-center group/video">
                      {#if block.content && (block.content.includes('youtube') || block.content.includes('youtu.be'))}
                        <div class="text-white text-sm text-center p-4">
                          <span class="text-3xl block mb-2">▶️</span>
                          <p class="font-medium">Видео с YouTube</p>
                          <a href={block.content} target="_blank" class="text-blue-400 hover:underline text-xs break-all">{block.content}</a>
                        </div>
                      {:else if block.content}
                        <!-- Если это ссылка на mp4 с вашего бэкенда -->
                        <video src={block.content} controls class="w-full h-full object-contain"></video>
                      {:else}
                        <div class="text-white text-sm">Ошибка: нет ссылки на видео</div>
                      {/if}
                    </div>
                  
                  <!-- ПРОСМОТР ТЕКСТА -->
                  {:else}
                    <div class="relative">
                      <p class="text-sm text-slate-600 whitespace-pre-wrap">{block.content || 'Пустой текст'}</p>
                      <button 
                        onclick={() => startEditing(block)}
                        class="text-blue-500 text-xs hover:underline mt-2 inline-block"
                      >
                        Редактировать текст
                      </button>
                    </div>
                  {/if}
                </div>
              </div>
            {/each}
              {/if}
            </div>
          </Card>
        </div>
      </div>
    {/if}
    {#if isAddingVideo}
  <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
    <div class="bg-white rounded-2xl shadow-xl max-w-md w-full overflow-hidden" role="dialog">
      <form onsubmit={addVideoToLibrary}>
        <div class="p-6">
          <h3 class="text-xl font-bold text-slate-800 mb-4">Добавить видео</h3>
          
          <div class="flex p-1 bg-slate-100 rounded-xl mb-4">
            <button type="button" onclick={() => uploadMode = 'file'} class="flex-1 py-1.5 text-sm font-medium rounded-lg transition {uploadMode === 'file' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500'}">С компьютера</button>
            <button type="button" onclick={() => uploadMode = 'url'} class="flex-1 py-1.5 text-sm font-medium rounded-lg transition {uploadMode === 'url' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500'}">По ссылке</button>
          </div>

          <div class="space-y-4">
            <Input label="Название видео" bind:value={newVideoTitle} placeholder="Например: Стендап у моста" />
            
            {#if uploadMode === 'file'}
              <!-- ВЫБОР СОБЫТИЯ -->
              <Select 
                label="Привязать к событию" 
                bind:value={selectedEventId} 
                options={events.map(e => ({ value: e.id, label: e.title }))} 
                placeholder="-- Выберите событие --" 
                required={uploadMode === 'file'} 
              />
              
              <div class="flex flex-col gap-1.5">
                <label class="text-sm font-medium text-slate-700">Файл (видео/аудио/фото)</label>
                <input 
                  type="file" 
                  accept="video/*,audio/*,image/*" 
                  onchange={handleFileChange}
                  class="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 transition"
                />
              </div>
            {:else}
              <Input label="Ссылка на видео (URL)" bind:value={newVideoUrl} placeholder="https://example.com/video.mp4" required={uploadMode === 'url'} />
            {/if}
          </div>
        </div>
        <div class="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2">
          <Button variant="secondary" type="button" onclick={() => isAddingVideo = false}>Отмена</Button>
          <Button type="submit" disabled={isUploading}>
            {isUploading ? 'Загрузка...' : 'Добавить'}
          </Button>
        </div>
      </form>
    </div>
  </div>
{/if}
  </div>