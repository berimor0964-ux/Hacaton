<script>
    import { onMount } from 'svelte';
    import { apiFetch } from '../lib/api.js';
    import { auth } from '../lib/auth.svelte.js';
    import Card from '../lib/ui/Card.svelte';
    import Button from '../lib/ui/Button.svelte';
    import Input from '../lib/ui/Input.svelte';
    import Select from '../lib/ui/Select.svelte';
    import Badge from '../lib/ui/Badge.svelte';
  
    let broadcasts = $state([]);
    let loading = $state(true);
    let error = $state('');
  
    // Создание эфира
    let isCreating = $state(false);
    let newTitle = $state('');
    let newStart = $state('');
    let newEnd = $state('');
  
    // Активный эфир (сетка)
    let activeBroadcast = $state(null);
    let items = $state([]);
    let projects = $state([]); // Для выбора репортажей
    
    // Добавление элемента
    let isAddingItem = $state(false);
    let itemType = $state('reportage');
    let itemProjectId = $state('');
    let itemStartTime = $state('');
    let itemEndTime = $state('');
  
    onMount(async () => {
      await loadBroadcasts();
      try {
        // Загружаем проекты, чтобы можно было добавить их в эфир как репортаж
        projects = await apiFetch('/projects');
      } catch (e) {
        console.error('Не удалось загрузить проекты', e);
      }
    });
  
    async function loadBroadcasts() {
      loading = true;
      try {
        broadcasts = await apiFetch('/broadcasts');
      } catch (e) {
        error = `Ошибка загрузки: ${e.message}`;
      } finally {
        loading = false;
      }
    }
  
    async function createBroadcast(e) {
      e.preventDefault();
      try {
        const created = await apiFetch('/broadcasts', {
          method: 'POST',
          body: JSON.stringify({
            title: newTitle,
            dateStart: new Date(newStart).toISOString(),
            dateEnd: new Date(newEnd).toISOString(),
            directorId: auth.user?.id || 1,
            status: 'draft'
          }),
        });
        broadcasts = [created, ...broadcasts];
        isCreating = false;
        newTitle = ''; newStart = ''; newEnd = '';
      } catch (e) {
        alert('Ошибка создания: ' + e.message);
      }
    }
  
    async function openBroadcast(id) {
      try {
        const full = await apiFetch(`/broadcasts/${id}`);
        activeBroadcast = full;
        // Сортируем элементы по времени начала
        items = [...(full.items || [])].sort((a, b) => new Date(a.startTime) - new Date(b.startTime));
      } catch (e) {
        alert('Ошибка загрузки эфира: ' + e.message);
      }
    }
  
    async function addItem(e) {
      e.preventDefault();
      try {
        const created = await apiFetch(`/broadcasts/${activeBroadcast.id}/items`, {
          method: 'POST',
          body: JSON.stringify({
            type: itemType,
            projectId: itemType === 'reportage' ? Number(itemProjectId) : null,
            startTime: new Date(itemStartTime).toISOString(),
            endTime: new Date(itemEndTime).toISOString(),
          }),
        });
        
        items = [...items, created].sort((a, b) => new Date(a.startTime) - new Date(b.startTime));
        isAddingItem = false;
        itemProjectId = ''; itemStartTime = ''; itemEndTime = '';
      } catch (e) {
        alert('Ошибка добавления: ' + e.message);
      }
    }
  
    const projectOptions = $derived(
      projects.map(p => ({ value: p.id, label: `Проект #${p.id} (${p.status})` }))
    );
  </script>
  
  <div class="max-w-6xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
      <div>
        <h1 class="text-2xl font-semibold text-slate-800">Эфиры</h1>
        <p class="text-sm text-slate-500 mt-1">Планирование сетки вещания</p>
      </div>
      {#if !activeBroadcast}
        <Button onclick={() => isCreating = true}>+ Новый эфир</Button>
      {/if}
    </div>
  
    {#if error}
      <div class="p-4 bg-rose-50 text-rose-700 rounded-xl text-sm border border-rose-200">{error}</div>
    {/if}
  
    <!-- Форма создания эфира -->
    {#if isCreating}
      <Card title="Новый эфир">
        <form onsubmit={createBroadcast} class="space-y-4">
          <Input label="Название эфира" bind:value={newTitle} placeholder="Вечерние новости" required />
          <div class="grid grid-cols-2 gap-4">
            <Input label="Начало" type="datetime-local" bind:value={newStart} required />
            <Input label="Конец" type="datetime-local" bind:value={newEnd} required />
          </div>
          <div class="flex gap-2">
            <Button type="submit">Создать</Button>
            <Button variant="secondary" onclick={() => isCreating = false}>Отмена</Button>
          </div>
        </form>
      </Card>
    {/if}
  
    <!-- СПИСОК ЭФИРОВ -->
    {#if !activeBroadcast}
      {#if loading}
        <div class="text-center py-10 text-slate-400">Загрузка...</div>
      {:else if broadcasts.length === 0}
        <Card>
          <div class="text-center py-10 text-slate-500">Пока нет эфиров. Создайте первый!</div>
        </Card>
      {:else}
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {#each broadcasts as b}
            <div 
              onclick={() => openBroadcast(b.id)}
              onkeydown={(e) => { if (e.key === 'Enter') openBroadcast(b.id); }}
              role="button"
              tabindex="0"
              class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition cursor-pointer group"
            >
              <div class="flex justify-between items-start mb-2">
                <Badge tone={b.status === 'ready' ? 'green' : b.status === 'on_air' ? 'rose' : 'slate'}>
                  {b.status}
                </Badge>
                <span class="text-slate-300 group-hover:text-brand-500 transition">→</span>
              </div>
              <h3 class="font-semibold text-slate-800 text-lg mb-1">{b.title}</h3>
              <p class="text-xs text-slate-500">
                {new Date(b.dateStart).toLocaleString('ru-RU')}
              </p>
            </div>
          {/each}
        </div>
      {/if}
    {/if}
  
    <!-- СЕТКА АКТИВНОГО ЭФИРА -->
    {#if activeBroadcast}
      <div class="flex items-center gap-4 mb-4">
        <Button variant="ghost" onclick={() => activeBroadcast = null}>← Назад к эфирам</Button>
        <h2 class="text-xl font-bold text-slate-800">{activeBroadcast.title}</h2>
        <Badge tone="amber">Черновик</Badge>
        <Button size="sm" class="ml-auto" onclick={() => isAddingItem = true}>+ Добавить в эфир</Button>
      </div>
  
      <Card padding="p-0">
        <div class="divide-y divide-slate-100">
          {#if items.length === 0}
            <div class="p-10 text-center text-slate-500">Сетка эфира пуста. Добавьте первый элемент.</div>
          {:else}
            {#each items as item}
              <div class="p-4 flex items-center gap-4 hover:bg-slate-50 transition">
                <div class="w-24 text-sm text-slate-500 font-mono">
                  {new Date(item.startTime).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                </div>
                <div class="flex-1">
                  <div class="flex items-center gap-2">
                    <Badge tone={item.type === 'reportage' ? 'brand' : item.type === 'ad' ? 'amber' : 'slate'}>
                      {item.type}
                    </Badge>
                    {#if item.projectId}
                      <span class="text-sm font-medium text-slate-800">Проект #{item.projectId}</span>
                    {:else}
                      <span class="text-sm font-medium text-slate-800">Блок ({item.type})</span>
                    {/if}
                  </div>
                </div>
                <div class="w-24 text-sm text-slate-400 text-right font-mono">
                  {new Date(item.endTime).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            {/each}
          {/if}
        </div>
      </Card>
    {/if}
  </div>
  
  <!-- Модалка добавления элемента -->
  {#if isAddingItem}
    <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
      <div class="bg-white rounded-2xl shadow-xl max-w-md w-full overflow-hidden" role="dialog">
        <form onsubmit={addItem}>
          <div class="p-6">
            <h3 class="text-xl font-bold text-slate-800 mb-4">Добавить в эфир</h3>
            <div class="space-y-4">
              <Select 
                label="Тип элемента" 
                bind:value={itemType} 
                options={[
                  { value: 'reportage', label: 'Репортаж (Проект)' },
                  { value: 'studio', label: 'Студия' },
                  { value: 'ad', label: 'Реклама' },
                  { value: 'film', label: 'Фильм' }
                ]} 
              />
              
              {#if itemType === 'reportage'}
                <Select 
                  label="Проект (Репортаж)" 
                  bind:value={itemProjectId} 
                  options={projectOptions} 
                  placeholder="-- Выберите проект --" 
                  required 
                />
              {/if}
  
              <div class="grid grid-cols-2 gap-4">
                <Input label="Начало" type="datetime-local" bind:value={itemStartTime} required />
                <Input label="Конец" type="datetime-local" bind:value={itemEndTime} required />
              </div>
            </div>
          </div>
          <div class="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2">
            <Button variant="secondary" type="button" onclick={() => isAddingItem = false}>Отмена</Button>
            <Button type="submit">Добавить</Button>
          </div>
        </form>
      </div>
    </div>
  {/if}