<script>
    import { onMount } from 'svelte';
    import { apiFetch } from '../lib/api.js';
    import { auth } from '../lib/auth.svelte.js';
    import Card from '../lib/ui/Card.svelte';
    import Button from '../lib/ui/Button.svelte';
    import Input from '../lib/ui/Input.svelte';
    import Badge from '../lib/ui/Badge.svelte';
  
    let events = $state([]);
    let loading = $state(true);
    let error = $state('');
    
    // Фильтры
    let statusFilter = $state('all');
    
    // Создание события
    let isCreating = $state(false);
    let newTitle = $state('');
    let newStart = $state('');
    let newEnd = $state('');
    let isSubmitting = $state(false);
  
    const canCreate = $derived(auth.hasRole('admin', 'director'));
  
    const filteredEvents = $derived(
      statusFilter === 'all' 
        ? events 
        : events.filter(e => e.status === statusFilter)
    );
  
    onMount(async () => {
      await loadEvents();
    });
  
    async function loadEvents() {
      loading = true;
      try {
        events = await apiFetch('/events');
      } catch (e) {
        error = `Ошибка загрузки: ${e.message}`;
      } finally {
        loading = false;
      }
    }
  
    async function createEvent(e) {
      e.preventDefault();
      isSubmitting = true;
      error = '';
      try {
        const created = await apiFetch('/events', {
          method: 'POST',
          body: JSON.stringify({
            title: newTitle,
            dateStart: new Date(newStart).toISOString(),
            dateEnd: new Date(newEnd).toISOString(),
          }),
        });
        events = [...events, created];
        isCreating = false;
        newTitle = ''; newStart = ''; newEnd = '';
      } catch (e) {
        error = e.message;
      } finally {
        isSubmitting = false;
      }
    }
  
    function getStatusTone(status) {
      if (status === 'planned') return 'blue';
      if (status === 'active') return 'amber';
      if (status === 'completed') return 'green';
      return 'slate';
    }
  
    function getStatusLabel(status) {
      if (status === 'planned') return 'Запланировано';
      if (status === 'active') return 'В работе';
      if (status === 'completed') return 'Завершено';
      return status;
    }

    async function deleteEvent(id) {
    if (!confirm('Вы уверены, что хотите удалить это событие?')) return;
    
    try {
      await apiFetch(`/events/${id}`, { method: 'DELETE' });
      events = events.filter(e => e.id !== id);
    } catch (e) {
      alert('Ошибка удаления: ' + e.message);
    }
  }
  </script>
  
  <div class="max-w-6xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
      <div>
        <h1 class="text-2xl font-semibold text-slate-800">События</h1>
        <p class="text-sm text-slate-500 mt-1">Все съемки и мероприятия</p>
      </div>
      {#if canCreate}
        <Button onclick={() => isCreating = !isCreating} variant={isCreating ? 'secondary' : 'primary'}>
          {isCreating ? 'Отмена' : '+ Создать событие'}
        </Button>
      {/if}
    </div>
  
    {#if error}
      <div class="p-4 bg-rose-50 text-rose-700 rounded-xl text-sm border border-rose-200">{error}</div>
    {/if}
  
    {#if isCreating}
      <Card title="Новое событие">
        <form onsubmit={createEvent} class="space-y-4">
          <Input label="Название" bind:value={newTitle} placeholder="Съемка интервью" required />
          <div class="grid grid-cols-2 gap-4">
            <Input label="Начало" type="datetime-local" bind:value={newStart} required />
            <Input label="Конец" type="datetime-local" bind:value={newEnd} required />
          </div>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? 'Создаем...' : 'Сохранить'}
          </Button>
        </form>
      </Card>
    {/if}
  
    <!-- Фильтры -->
    <div class="flex gap-2">
      {#each ['all', 'planned', 'active', 'completed'] as filter}
        <button
          onclick={() => statusFilter = filter}
          class="px-4 py-2 rounded-xl text-sm font-medium transition
                 {statusFilter === filter ? 'bg-slate-800 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}"
        >
          {filter === 'all' ? 'Все' : getStatusLabel(filter)}
        </button>
      {/each}
    </div>
  
    <!-- Таблица -->
    <Card padding="p-0">
      <div class="overflow-x-auto">
        <table class="w-full text-left text-sm">
            <thead class="bg-slate-50 text-slate-500 border-b border-slate-200">
                <tr>
                  <th class="px-6 py-4 font-medium">Название</th>
                  <th class="px-6 py-4 font-medium">Начало</th>
                  <th class="px-6 py-4 font-medium">Конец</th>
                  <th class="px-6 py-4 font-medium">Статус</th>
                  <th class="px-6 py-4 font-medium text-right">Действия</th> <!-- НОВАЯ КОЛОНКА -->
                </tr>
              </thead>
          <tbody class="divide-y divide-slate-100">
            {#if loading}
              <tr><td colspan="4" class="px-6 py-8 text-center text-slate-400">Загрузка...</td></tr>
            {:else if filteredEvents.length === 0}
              <tr><td colspan="4" class="px-6 py-8 text-center text-slate-400">Нет событий</td></tr>
            {:else}
              {#each filteredEvents as event}
              <tr class="hover:bg-slate-50 transition">
                <td class="px-6 py-4 font-medium text-slate-800">{event.title}</td>
                <td class="px-6 py-4 text-slate-600">{new Date(event.dateStart).toLocaleString('ru-RU')}</td>
                <td class="px-6 py-4 text-slate-600">{new Date(event.dateEnd).toLocaleString('ru-RU')}</td>
                <td class="px-6 py-4">
                  <Badge tone={getStatusTone(event.status)}>{getStatusLabel(event.status)}</Badge>
                </td>
                
                <td class="px-6 py-4 text-right">
                  {#if canCreate}
                    <button 
                      onclick={() => deleteEvent(event.id)}
                      class="text-slate-400 hover:text-rose-600 p-2 rounded-lg hover:bg-rose-50 transition"
                      title="Удалить событие"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
                    </button>
                  {/if}
                </td>
              </tr>
              {/each}
            {/if}
          </tbody>
        </table>
      </div>
    </Card>
  </div>