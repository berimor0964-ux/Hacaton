<script>
    import { onMount } from 'svelte';
    import { apiFetch } from '../lib/api.js';
    import { auth } from '../lib/auth.svelte.js';
    import Card from '../lib/ui/Card.svelte';
    import Button from '../lib/ui/Button.svelte';
    import Badge from '../lib/ui/Badge.svelte';
  
    let projects = $state([]);
    let loading = $state(true);
    let error = $state('');
  
    // Модалка ревью
    let activeProject = $state(null);
    let reviewComment = $state('');
    let isSubmitting = $state(false);
  
    onMount(async () => {
      await loadProjectsForReview();
    });
  
    async function loadProjectsForReview() {
    loading = true;
    try {
      const allProjects = await apiFetch('/editorial/projects'); 
      projects = allProjects.filter(p => p.status === 'review');
    } catch (e) {
      error = `Ошибка загрузки: ${e.message}`;
    } finally {
      loading = false;
    }
  }
  
    async function submitReview(e) {
    e.preventDefault();
    if (!activeProject) return;
    
    isSubmitting = true;
    try {
      await apiFetch(`/editorial/projects/${activeProject.id}/review`, {
        method: 'POST',
        body: JSON.stringify({
          editorId: auth.user.id, // <--- Берем ID редактора
          status: 'approved',     // <--- Проверьте, как называется статус в вашем enum
          comments: [reviewComment] // <--- Возможно, бэкенд ждет массив: [reviewComment]
        }),
      });
      
      projects = projects.filter(p => p.id !== activeProject.id);
      activeProject = null;
      reviewComment = '';
    } catch (e) {
      alert('Ошибка: ' + e.message);
    } finally {
      isSubmitting = false;
    }
  }

  async function sendToRework(e) {
    e.preventDefault();
    if (!reviewComment.trim()) return alert('Напишите комментарий для монтажера');
    
    isSubmitting = true;
    try {
      await apiFetch(`/editorial/projects/${activeProject.id}/review`, {
        method: 'POST',
        body: JSON.stringify({
          editorId: auth.user.id,
          status: 'rework',       // <--- Проверьте, как называется статус в вашем enum
          comments: reviewComment
        }),
      });
      
      projects = projects.filter(p => p.id !== activeProject.id);
      activeProject = null;
      reviewComment = '';
    } catch (e) {
      alert('Ошибка: ' + e.message);
    } finally {
      isSubmitting = false;
    }
  }
  </script>
  
  <div class="max-w-4xl mx-auto space-y-6">
    <div>
      <h1 class="text-2xl font-semibold text-slate-800">Ревью</h1>
      <p class="text-sm text-slate-500 mt-1">Проверка готовых проектов от монтажеров</p>
    </div>
  
    {#if error}
      <div class="p-4 bg-rose-50 text-rose-700 rounded-xl text-sm border border-rose-200">{error}</div>
    {/if}
  
    {#if loading}
      <div class="text-center py-10 text-slate-400">Загрузка...</div>
    {:else if projects.length === 0}
      <Card>
        <div class="text-center py-10 text-slate-500">
          Нет проектов, ожидающих проверки. Все сделано! 🎉
        </div>
      </Card>
    {:else}
      <div class="space-y-4">
        {#each projects as project}
          <Card>
            <div class="flex flex-col md:flex-row gap-6">
              <!-- Левая часть: Инфо и видео -->
              <div class="flex-1">
                <div class="flex items-center gap-2 mb-2">
                  <Badge tone="amber">На ревью</Badge>
                  <span class="text-xs text-slate-400">ID: {project.id}</span>
                </div>
                <h3 class="font-semibold text-slate-800 text-lg mb-1">
                  {project.story?.title || 'Без названия'}
                </h3>
                <p class="text-sm text-slate-500 mb-4">
                  {project.story?.description || 'Описание отсутствует'}
                </p>
                
                <!-- Плеер (если есть ссылка на видео) -->
                {#if project.render?.videoUrl || project.videoUrl}
                  <div class="bg-slate-900 rounded-lg overflow-hidden aspect-video max-w-md">
                    <video src={project.render?.videoUrl || project.videoUrl} controls class="w-full h-full object-contain"></video>
                  </div>
                {:else}
                  <div class="text-sm text-slate-400 bg-slate-100 p-4 rounded-lg">Видео не прикреплено</div>
                {/if}
              </div>
  
              <!-- Правая часть: Кнопки -->
              <div class="w-full md:w-64 flex flex-col justify-center gap-3 border-t md:border-t-0 md:border-l border-slate-100 pt-4 md:pt-0 md:pl-6">
                <Button onclick={() => { activeProject = project; reviewComment = ''; }} variant="primary" class="w-full">
                  Проверить
                </Button>
              </div>
            </div>
          </Card>
        {/each}
      </div>
    {/if}
  </div>
  
  <!-- Модалка проверки -->
  {#if activeProject}
    <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
      <div class="bg-white rounded-2xl shadow-xl max-w-2xl w-full overflow-hidden" role="dialog">
        <div class="p-6">
          <div class="flex justify-between items-start mb-4">
            <h3 class="text-xl font-bold text-slate-800">Проверка проекта</h3>
            <button onclick={() => activeProject = null} class="text-slate-400 hover:text-slate-600">✕</button>
          </div>
          
          <p class="text-sm text-slate-500 mb-4">
            {activeProject.story?.title}
          </p>
  
          <!-- Плеер в модалке -->
          {#if activeProject.render?.videoUrl || activeProject.videoUrl}
            <div class="bg-slate-900 rounded-lg overflow-hidden aspect-video mb-4">
              <video src={activeProject.render?.videoUrl || activeProject.videoUrl} controls class="w-full h-full object-contain"></video>
            </div>
          {/if}
          
          <form id="review-form" onsubmit={submitReview}>
            <div class="space-y-1.5">
              <label class="text-sm font-medium text-slate-700">Комментарий (обязателен при отправке на доработку)</label>
              <textarea 
                bind:value={reviewComment}
                rows="3"
                placeholder="Что нужно исправить?"
                class="w-full p-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              ></textarea>
            </div>
          </form>
        </div>
        
        <div class="p-4 bg-slate-50 border-t border-slate-200 flex justify-between gap-2">
          <Button type="button" variant="danger" onclick={sendToRework} disabled={isSubmitting}>
            На доработку
          </Button>
          <div class="flex gap-2">
            <Button variant="secondary" type="button" onclick={() => activeProject = null}>Отмена</Button>
            <Button type="submit" form="review-form" disabled={isSubmitting}>
              {isSubmitting ? 'Отправка...' : 'Утвердить'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  {/if}