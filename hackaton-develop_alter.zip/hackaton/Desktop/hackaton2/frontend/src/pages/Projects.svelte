<script>
    import { onMount } from 'svelte';
    import { apiFetch } from '../lib/api.js';
    import { auth } from '../lib/auth.svelte.js';
    import Card from '../lib/ui/Card.svelte';
    import Button from '../lib/ui/Button.svelte';
    import Input from '../lib/ui/Input.svelte';
    import Badge from '../lib/ui/Badge.svelte';
  
    let projects = $state([]);
    let loading = $state(true);
    let error = $state('');
  
    // Модалка для рендера
    let activeProject = $state(null);
    let renderUrl = $state('');
    let isSubmitting = $state(false);
    let selectedFile = $state(null);
  let isUploading = $state(false);

  function handleFileChange(e) {
    selectedFile = e.target.files[0];
  }

  
  
    onMount(async () => {
      await loadProjects();
    });
  
    async function loadProjects() {
      loading = true;
      try {
        const userId = auth.user?.id;
        if (!userId) throw new Error('Пользователь не авторизован');
        
        // Загружаем проекты, назначенные на текущего монтажера
        projects = await apiFetch(`/projects/montage/${userId}`);
      } catch (e) {
        error = `Ошибка загрузки проектов: ${e.message}`;
      } finally {
        loading = false;
      }
    }
  
    async function submitRender(e) {
    e.preventDefault();
    if (!selectedFile) return alert('Выберите файл');
    
    isUploading = true;
    try {
      const formData = new FormData();
      formData.append('file', selectedFile);
      
      // Отправляем на НОВЫЙ эндпоинт
      await apiFetch(`/projects/${activeProject.id}/render-upload`, {
        method: 'POST',
        body: formData,
      });
      
      // Обновляем статус
      projects = projects.map(p => 
        p.id === activeProject.id ? { ...p, status: 'review' } : p
      );
      
      activeProject = null;
      selectedFile = null;
    } catch (e) {
      alert('Ошибка загрузки рендера: ' + e.message);
    } finally {
      isUploading = false;
    }
  }
  
    function getStatusTone(status) {
      if (status === 'assigned') return 'blue';
      if (status === 'in_work') return 'amber';
      if (status === 'review') return 'brand';
      if (status === 'rework') return 'rose';
      if (status === 'done') return 'green';
      return 'slate';
    }
  
    function getStatusLabel(status) {
      if (status === 'assigned') return 'Назначен';
      if (status === 'in_work') return 'В работе';
      if (status === 'review') return 'На ревью';
      if (status === 'rework') return 'На доработке';
      if (status === 'done') return 'Готово';
      return status;
    }
  </script>
  
  <div class="max-w-5xl mx-auto space-y-6">
    <div>
      <h1 class="text-2xl font-semibold text-slate-800">Монтаж</h1>
      <p class="text-sm text-slate-500 mt-1">Проекты, требующие вашего внимания</p>
    </div>
  
    {#if error}
      <div class="p-4 bg-rose-50 text-rose-700 rounded-xl text-sm border border-rose-200">{error}</div>
    {/if}
  
    {#if loading}
      <div class="text-center py-10 text-slate-400">Загрузка проектов...</div>
    {:else if projects.length === 0}
      <Card>
        <div class="text-center py-10 text-slate-500">
          У вас пока нет назначенных проектов.
        </div>
      </Card>
    {:else}
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        {#each projects as project}
          <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div class="flex justify-between items-start mb-3">
                <Badge tone={getStatusTone(project.status)}>
                  {getStatusLabel(project.status)}
                </Badge>
                <span class="text-xs text-slate-400">ID: {project.id}</span>
              </div>
              
              <h3 class="font-semibold text-slate-800 text-lg mb-1">
                {project.story?.title || 'Сюжет без названия'}
              </h3>
              <p class="text-sm text-slate-500 mb-4">
                {project.story?.description || 'Описание отсутствует'}
              </p>
            </div>
  
            <div class="pt-4 border-t border-slate-100">
              {#if project.status === 'assigned' || project.status === 'in_work' || project.status === 'rework'}
                <Button onclick={() => activeProject = project} class="w-full">
                  Загрузить рендер
                </Button>
              {:else if project.status === 'review'}
                <div class="text-sm text-center text-brand-600 bg-brand-50 py-2 rounded-lg font-medium">
                  Ожидает проверки редактора
                </div>
              {:else if project.status === 'done'}
                <div class="text-sm text-center text-emerald-600 bg-emerald-50 py-2 rounded-lg font-medium">
                  ✓ Проект завершен
                </div>
              {/if}
            </div>
          </div>
        {/each}
      </div>
    {/if}
  </div>
  
  <!-- Модалка загрузки рендера -->
  {#if activeProject}
    <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
      <div class="bg-white rounded-2xl shadow-xl max-w-md w-full overflow-hidden" role="dialog">
        <form onsubmit={submitRender}>
            <div class="p-6">
              <h3 class="text-xl font-bold text-slate-800 mb-4">Загрузить рендер</h3>
              <p class="text-sm text-slate-500 mb-4">
                Проект: <strong>{activeProject.story?.title || 'Без названия'}</strong>
              </p>
              
              <div class="flex flex-col gap-1.5">
                <label class="text-sm font-medium text-slate-700">Файл видео</label>
                <input 
                  type="file" 
                  accept="video/*" 
                  onchange={handleFileChange}
                  class="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 transition"
                />
              </div>
            </div>
            <div class="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2">
              <Button variant="secondary" type="button" onclick={() => activeProject = null}>Отмена</Button>
              <Button type="submit" disabled={isUploading}>
                {isUploading ? 'Загрузка...' : 'Отправить на ревью'}
              </Button>
            </div>
          </form>
      </div>
    </div>
  {/if}