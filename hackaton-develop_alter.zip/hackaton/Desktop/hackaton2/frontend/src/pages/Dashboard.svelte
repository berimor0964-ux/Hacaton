<!-- src/pages/Dashboard.svelte -->
<script>
    import { auth } from '../lib/auth.svelte.js';
    import { router, routes } from '../lib/router.svelte.js';
    import Card from '../lib/ui/Card.svelte';
    import Badge from '../lib/ui/Badge.svelte';
  
    const greeting = $derived.by(() => {
      const h = new Date().getHours();
      if (h < 12) return 'Доброе утро';
      if (h < 18) return 'Добрый день';
      return 'Добрый вечер';
    });
  
    const tiles = $derived(
      Object.entries(routes)
        .filter(([key, cfg]) => key !== 'login' && key !== 'dashboard')
        .filter(([_, cfg]) => !cfg.roles || auth.hasRole(...cfg.roles))
        .map(([key, cfg]) => ({
          key,
          label: cfg.label,
          icon: cfg.icon,
          hint:
            key === 'calendar'    ? 'Планирование съёмок' :
            key === 'events'      ? 'Все события и статусы' :
            key === 'assignments' ? 'Распределение команды' :
            key === 'stories'     ? 'Конструктор сюжетов' :
            key === 'projects'    ? 'Проекты монтажа' :
            key === 'editorial'   ? 'Ревью и утверждение' :
            key === 'broadcasts'  ? 'Сетка эфира' :
            key === 'tasks'       ? 'Канбан-доска' : '',
        }))
    );
  </script>
  
  <div class="max-w-6xl mx-auto">
    <div class="mb-8">
      <h1 class="text-2xl font-semibold text-slate-800">{greeting}, {auth.user?.name}!</h1>
      <p class="text-sm text-slate-500 mt-1">
        Быстрый доступ к разделам, соответствующим вашей роли.
      </p>
      <div class="mt-3 flex flex-wrap gap-2">
        {#each auth.user?.roles ?? [] as r}
          <Badge tone="brand">{r.name}</Badge>
        {/each}
      </div>
    </div>
  
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {#each tiles as t (t.key)}
        <button
          onclick={() => router.navigate(t.key)}
          class="text-left bg-white rounded-2xl p-5 border border-slate-200 shadow-sm
                 hover:shadow-md hover:border-brand-300 transition group"
        >
          <div class="flex items-start justify-between">
            <div class="text-2xl">{t.icon}</div>
            <span class="text-slate-300 group-hover:text-brand-500 transition">→</span>
          </div>
          <div class="mt-3">
            <div class="font-semibold text-slate-800">{t.label}</div>
            <div class="text-sm text-slate-500 mt-1">{t.hint}</div>
          </div>
        </button>
      {/each}
    </div>
  
    {#if tiles.length === 0}
      <Card title="Нет доступных разделов">
        <p class="text-sm text-slate-500">Обратитесь к администратору для назначения роли.</p>
      </Card>
    {/if}
  </div>