<script>
    import { onMount } from 'svelte';
    import { apiFetch } from '../lib/api.js';
    import { auth } from '../lib/auth.svelte.js';
    import { router } from '../lib/router.svelte.js';
    import Input from '../lib/ui/Input.svelte';
    import Select from '../lib/ui/Select.svelte';
    import Card from '../lib/ui/Card.svelte';
    import Button from '../lib/ui/Button.svelte';
  
    let mode = $state('login'); // 'login' | 'register'
    let loading = $state(false);
    let error = $state('');
  
    // login
    let loginEmail = $state('');
    let loginPassword = $state('');
  
    // register
    let regEmail = $state('');
    let regPassword = $state('');
    let regName = $state('');
    let regRoleId = $state('');
    let roles = $state([]);
    let rolesLoading = $state(false);
  
    onMount(async () => {
      if (auth.isAuth) router.navigate('dashboard');
    });
  
    const roleOptions = $derived(
      roles.map(r => ({ value: r.id, label: r.name }))
    );
  
    async function loadRoles() {
      rolesLoading = true;
      try {
        roles = await apiFetch('/roles');
      } catch (e) {
        error = `Не удалось загрузить роли: ${e.message}`;
      } finally {
        rolesLoading = false;
      }
    }
  
    async function doLogin(e) {
    e.preventDefault();
    error = '';
    loading = true;
    try {
      // 1. Отправляем POST запрос на /auth/login
      const response = await apiFetch('/auth/login', {
        method: 'POST',
        body: JSON.stringify({
          email: loginEmail,
          password: loginPassword,
        }),
      });

      console.log('Ответ от бэкенда:', response);

      // 2. Если бэкенд вернул только базовые данные (как на скриншоте)
      // нам нужно подгрузить роли.
      let userWithRoles = response;

      // Если ролей нет, делаем запрос к /users, чтобы найти этого пользователя с ролями
      if (!userWithRoles.roles) {
        try {
          const allUsers = await apiFetch('/users');
          const fullUser = allUsers.find(u => u.id === response.id);
          if (fullUser) {
            userWithRoles = fullUser;
          }
          auth.login(userWithRoles);
        } catch (err) {
          console.warn('Не удалось загрузить роли:', err);
        }
      }

      router.navigate('dashboard');
      
    } catch (e) {
      error = e.message;
    } finally {
      loading = false;
    }
  }
  
    async function doRegister(e) {
      e.preventDefault();
      error = '';
      loading = true;
      try {
        const created = await apiFetch('/users', {
          method: 'POST',
          body: JSON.stringify({
            email: regEmail,
            password: regPassword,
            name: regName,
            roleIds: regRoleId ? [Number(regRoleId)] : [],
          }),
        });
        auth.login({
          ...created,
          roles: created.roles ?? roles.filter(r => r.id === Number(regRoleId)),
        });
        router.navigate('dashboard');
      } catch (e) {
        error = e.message;
      } finally {
        loading = false;
      }
    }
  
    $effect(() => {
      if (mode === 'register' && roles.length === 0 && !rolesLoading) {
        loadRoles();
      }
    });
  
    function switchMode(next) {
      mode = next;
      error = '';
    }
  </script>
  
  <div class="text-center mb-6">
    <!-- Для проверки заменил bg-brand-600 на bg-blue-600 -->
    <div class="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-blue-600 text-white text-xl font-bold mb-3">Т</div>
    <h1 class="text-2xl font-semibold text-slate-800">ТелеПрод</h1>
    <p class="text-sm text-slate-500">Управление телепроизводством</p>
  </div>
  
  <Card>
    <div class="flex p-1 bg-slate-100 rounded-xl mb-5">
      <button
        type="button"
        onclick={() => switchMode('login')}
        class="flex-1 py-2 text-sm font-medium rounded-lg transition
               {mode === 'login' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500'}"
      >Вход</button>
      <button
        type="button"
        onclick={() => switchMode('register')}
        class="flex-1 py-2 text-sm font-medium rounded-lg transition
               {mode === 'register' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500'}"
      >Регистрация</button>
    </div>
  
    {#if error}
      <div class="mb-4 px-3 py-2 rounded-lg bg-rose-50 border border-rose-200 text-sm text-rose-700">
        {error}
      </div>
    {/if}
  
    <!-- ВОТ ЗДЕСЬ БЫЛА ОШИБКА. Теперь блоки {#if} и {:else} закрыты правильно -->
    {#if mode === 'login'}
      <form onsubmit={doLogin} class="space-y-4">
        <Input label="Email" type="email" bind:value={loginEmail} placeholder="you@studio.ru" required />
        <Input label="Пароль" type="password" bind:value={loginPassword} placeholder="••••••••" required />
        <Button type="submit" variant="primary" size="md" disabled={loading} class="w-full">
          {loading ? 'Входим…' : 'Войти'}
        </Button>
      </form>
    {:else}
      <form onsubmit={doRegister} class="space-y-4">
        <Input label="Имя" bind:value={regName} placeholder="Иван Иванов" required />
        <Input label="Email" type="email" bind:value={regEmail} placeholder="you@studio.ru" required />
        <Input label="Пароль" type="password" bind:value={regPassword} placeholder="••••••••" required />
        
        <Select
          label="Роль"
          bind:value={regRoleId}
          options={roleOptions}
          placeholder={rolesLoading ? 'Загрузка ролей…' : 'Выберите роль'}
          required
        />
        <Button type="submit" variant="primary" size="md" disabled={loading || rolesLoading} class="w-full">
          {loading ? 'Создаём…' : 'Зарегистрироваться'}
        </Button>
      </form>
    {/if}
  </Card>

  