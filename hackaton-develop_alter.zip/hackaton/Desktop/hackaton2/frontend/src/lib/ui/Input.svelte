<script>
    let { label = '', type = 'text', value = $bindable(''), placeholder = '', required = false } = $props();
  </script>
  
  <div class="flex flex-col gap-1.5 mb-4">
    {#if label}
      <label class="text-sm font-medium text-slate-700">{label}</label>
    {/if}
    <input
      {type}
      bind:value
      {placeholder}
      {required}
      class="w-full border border-slate-300 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
    />
  </div>