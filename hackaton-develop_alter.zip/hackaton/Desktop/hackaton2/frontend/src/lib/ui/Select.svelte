<script>
    let { label = '', value = $bindable(''), options = [], placeholder = 'Выберите...', ...rest } = $props();
  </script>
  
  <label class="block">
    {#if label}
      <span class="block text-sm font-medium text-slate-700 mb-1.5">{label}</span>
    {/if}
    <select
      bind:value
      class="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 bg-white transition
             focus:outline-none focus:ring-2 focus:ring-brand-500/40 focus:border-brand-500"
      {...rest}
    >
      <option value="" disabled>{placeholder}</option>
      {#each options as opt}
        <option value={opt.value}>{opt.label}</option>
      {/each}
    </select>
  </label>