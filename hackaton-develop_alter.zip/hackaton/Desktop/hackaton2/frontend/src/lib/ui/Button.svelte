<script>
    let { children, type = 'button', onclick, disabled = false, variant = 'primary', class: className = '' } = $props();
  
    const base = 'inline-flex items-center justify-center font-medium py-2.5 px-4 rounded-xl transition duration-200 disabled:opacity-50 disabled:pointer-events-none';
    
    const variants = {
      primary: 'bg-blue-600 hover:bg-blue-700 text-white',
      danger: 'bg-rose-600 hover:bg-rose-700 text-white',
      secondary: 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50',
      ghost: 'text-slate-600 hover:bg-slate-100'
    };
  </script>
  
  <button
    {type}
    {onclick}
    {disabled}
    class="{base} {variants[variant]} {className}"
  >
    {@render children?.()}
  </button>