<script>
    let { tone = 'slate', children } = $props();
    const tones = {
      slate:   'bg-slate-100 text-slate-700',
      green:   'bg-emerald-100 text-emerald-700',
      blue:    'bg-sky-100 text-sky-700',
      amber:   'bg-amber-100 text-amber-700',
      rose:    'bg-rose-100 text-rose-700',
      brand:   'bg-brand-50 text-brand-700',
    };
    const cls = $derived(`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${tones[tone]}`);
  </script>
  
  <span class={cls}>{@render children?.()}</span>