<script>
    let { title = '', subtitle = '', padding = 'p-5', children } = $props();
  </script>
  
  <div class="bg-white rounded-2xl shadow-sm border border-slate-200 {padding}">
    {#if title}
      <div class="mb-4">
        <h3 class="text-lg font-semibold text-slate-800">{title}</h3>
        {#if subtitle}<p class="text-sm text-slate-500">{subtitle}</p>{/if}
      </div>
    {/if}
    {@render children?.()}
  </div>