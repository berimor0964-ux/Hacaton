<script>
    import { onMount } from 'svelte';
    import { auth } from './lib/auth.svelte.js';
    import { router } from './lib/router.svelte.js';
    import Sidebar from './components/Sidebar.svelte';
    import Header from './components/Header.svelte';
    import Calendar from './pages/Calendar.svelte';
    import Events from './pages/Events.svelte';
  
    import Login from './pages/Login.svelte';
    import Dashboard from './pages/Dashboard.svelte';
    import Assignments from './pages/Assignments.svelte';
    import Stories from './pages/Stories.svelte';
    import Projects from './pages/Projects.svelte';
    import Editorial from './pages/Editorial.svelte';
    import Broadcasts from './pages/Broadcasts.svelte';
    // import Tasks from './pages/Tasks.svelte';
  
    // Инициализация: проверяем сохраненного пользователя
    onMount(() => {
      auth.restore();
      if (!auth.isAuth && router.page !== 'login') {
        router.navigate('login');
      }
      if (auth.isAuth && router.page === 'login') {
        router.navigate('dashboard');
      }
    });
  
    // Объявляем showChrome строго ДО разметки!
    const showChrome = $derived(auth.isAuth && router.page !== 'login');
  </script>
  
  {#if !showChrome}
    <!-- ЭКРАН ВХОДА (без сайдбара и хедера) -->
    <main class="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-slate-50 to-brand-50">
      <div class="w-full max-w-md">
        <Login />
      </div>
    </main>
  {:else}
    <!-- ОСНОВНОЙ ИНТЕРФЕЙС -->
    <div class="flex h-screen overflow-hidden bg-slate-50">
      <Sidebar />
      <div class="flex-1 flex flex-col min-w-0">
        <Header />
        <main class="flex-1 overflow-y-auto p-6">
          {#if router.page === 'dashboard'}
            <Dashboard />
          {/if}
          {#if router.page === 'calendar'}<Calendar />{/if}
          {#if router.page === 'events'}<Events />{/if}
          {#if router.page === 'assignments'}
  <Assignments />
{/if}
{#if router.page === 'stories'}
  <Stories />
{/if}
{#if router.page === 'projects'}
  <Projects />
{/if}
{#if router.page === 'editorial'}
  <Editorial />
{/if}
{#if router.page === 'broadcasts'}
  <Broadcasts />
{/if}
        </main>
      </div>
    </div>
  {/if}